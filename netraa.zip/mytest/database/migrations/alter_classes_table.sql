-- Add status column to classes table if it doesn't exist
ALTER TABLE classes 
ADD COLUMN IF NOT EXISTS status ENUM('active', 'inactive') DEFAULT 'active';

-- Update existing records to have 'active' status
UPDATE classes SET status = 'active' WHERE status IS NULL; 