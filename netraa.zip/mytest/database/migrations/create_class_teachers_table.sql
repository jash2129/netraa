CREATE TABLE IF NOT EXISTS class_teachers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    class_id INT NOT NULL,
    teacher_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_class_teacher (class_id, teacher_id)
);

-- Insert some sample data
INSERT INTO class_teachers (class_id, teacher_id) 
SELECT c.id, u.id 
FROM classes c, users u 
WHERE u.role = 'teacher' 
LIMIT 1; 