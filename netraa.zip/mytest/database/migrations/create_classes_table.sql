-- Drop existing table if it exists
DROP TABLE IF EXISTS classes;

-- Create Classes Table
CREATE TABLE IF NOT EXISTS classes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    department_id INT,
    semester INT NOT NULL,
    section VARCHAR(10),
    academic_year VARCHAR(10) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample classes
INSERT INTO classes (name, department_id, semester, section, academic_year) VALUES
('CSE-1A', 1, 1, 'A', '2023-2024'),
('CSE-1B', 1, 1, 'B', '2023-2024'),
('ECE-1A', 2, 1, 'A', '2023-2024'),
('MECH-1A', 3, 1, 'A', '2023-2024'); 