<?php
$page_title = 'Forgot Password';
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = new Database();
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $username = $_POST['username'] ?? '';

    if (empty($email) || empty($username)) {
        $errors[] = "Both email and username are required";
    } else {
        // Check if user exists
        $user = $db->query("
            SELECT id, email, username, first_name 
            FROM users 
            WHERE email = '$email' AND username = '$username'
        ")->fetch_assoc();

        if ($user) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Store token in database
            $result = $db->query("
                INSERT INTO password_resets (user_id, token, expiry)
                VALUES ({$user['id']}, '$token', '$expiry')
            ");

            if ($result) {
                // Send reset email
                $reset_link = SITE_URL . "/reset_password.php?token=" . $token;
                $to = $user['email'];
                $subject = "Password Reset Request";
                
                $message = "Dear {$user['first_name']},\n\n";
                $message .= "We received a request to reset your password. ";
                $message .= "Click the link below to reset your password:\n\n";
                $message .= $reset_link . "\n\n";
                $message .= "This link will expire in 1 hour.\n\n";
                $message .= "If you didn't request this, please ignore this email.\n\n";
                $message .= "Best regards,\n";
                $message .= SITE_NAME;

                $headers = "From: " . SITE_EMAIL . "\r\n";
                $headers .= "Reply-To: " . SITE_EMAIL . "\r\n";
                $headers .= "X-Mailer: PHP/" . phpversion();

                if (mail($to, $subject, $message, $headers)) {
                    $success = "Password reset instructions have been sent to your email.";
                    logActivity($user['id'], 'Password Reset Request', 'User requested password reset');
                } else {
                    $errors[] = "Failed to send reset email. Please try again.";
                }
            } else {
                $errors[] = "Failed to process reset request. Please try again.";
            }
        } else {
            $errors[] = "No account found with these credentials.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-lock"></i> Forgot Password</h1>
                <p>Enter your email and username to reset your password</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label for="username">Username <span class="required">*</span></label>
                    <input type="text" id="username" name="username" required 
                           value="<?php echo $_POST['username'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email Address <span class="required">*</span></label>
                    <input type="email" id="email" name="email" required 
                           value="<?php echo $_POST['email'] ?? ''; ?>">
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-paper-plane"></i> Send Reset Link
                    </button>
                    <a href="login.php" class="btn btn-link btn-block">
                        <i class="fas fa-arrow-left"></i> Back to Login
                    </a>
                </div>
            </form>
        </div>
    </div>

    <style>
    .auth-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f3f4f6;
        padding: 20px;
    }

    .auth-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
        padding: 30px;
    }

    .auth-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .auth-header h1 {
        font-size: 24px;
        color: #1f2937;
        margin-bottom: 10px;
    }

    .auth-header p {
        color: #6b7280;
        margin: 0;
    }

    .auth-form .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
        color: #374151;
    }

    .form-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        font-size: 14px;
    }

    .required {
        color: #dc2626;
    }

    .btn-block {
        width: 100%;
        margin-bottom: 10px;
    }

    .btn-link {
        color: #4f46e5;
        text-decoration: none;
    }

    .btn-link:hover {
        text-decoration: underline;
    }

    .alert {
        padding: 12px 20px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .alert-success {
        background: #dcfce7;
        border: 1px solid #bbf7d0;
        color: #15803d;
    }

    .alert-danger {
        background: #fee2e2;
        border: 1px solid #fecaca;
        color: #dc2626;
    }

    .alert ul {
        margin: 0;
        padding-left: 20px;
    }
    </style>
</body>
</html> 