<?php
require_once '../../includes/init.php';
function requireAuth($allowed_roles = []) {
    initSession();
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
        $_SESSION['error'] = "Please login to continue.";
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header("Location: " . BASE_URL . "login.php");
        exit;
    }
    
    // Check if user role is allowed
    if (!empty($allowed_roles) && !in_array($_SESSION['role'], $allowed_roles)) {
        $_SESSION['error'] = "You are not authorized to access this page.";
        
        // Redirect based on role
        $redirect_path = match($_SESSION['role']) {
            'admin' => 'modules/admin/dashboard.php',
            'teacher' => 'modules/teacher/dashboard.php',
            'student' => 'modules/student/dashboard.php',
            default => 'login.php'
        };
        
        header("Location: " . BASE_URL . $redirect_path);
        exit;
    }
    
    // Update last activity
    $_SESSION['last_activity'] = time();
    
    return true;
}

// Session timeout check
function checkSessionTimeout($timeout = 1800) { // 30 minutes
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout)) {
        session_unset();
        session_destroy();
        $_SESSION['error'] = "Session expired. Please login again.";
        header("Location: " . BASE_URL . "login.php");
        exit;
    }
} 