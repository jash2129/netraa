<?php
// Define root path
define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);

// Error reporting in development
if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Autoload required files
$required_files = [
    'config.php',
    'db.php',
    'functions.php'
];

foreach ($required_files as $file) {
    $path = ROOT_PATH . 'includes/' . $file;
    if (!file_exists($path)) {
        die("Critical Error: Required file '$file' not found!");
    }
    require_once $path;
}

// Initialize session with secure settings
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        // Secure session settings
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
        
        session_start();
    }
}

// Initialize database connection
function initDatabase() {
    try {
        return new Database();
    } catch (Exception $e) {
        logError('Database connection failed: ' . $e->getMessage());
        die("Database connection failed. Please try again later.");
    }
}

// Error logging function
function logError($message, $severity = 'ERROR') {
    $log_file = ROOT_PATH . 'logs/error.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[$timestamp] [$severity] $message" . PHP_EOL;
    
    if (!is_dir(dirname($log_file))) {
        mkdir(dirname($log_file), 0755, true);
    }
    
    error_log($log_message, 3, $log_file);
}

// Debug function
function debug($data, $die = false) {
    if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
        if ($die) die();
    }
}

// Initialize session
initSession();

// Set default timezone
date_default_timezone_set('Asia/Kolkata');

// Initialize database
$db = initDatabase(); 