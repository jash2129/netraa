<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'my_db');

// Site configuration
if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost/college');
}

if (!defined('SITE_NAME')) {
    define('SITE_NAME', 'College Management System');
}

// Other configurations
define('DEFAULT_TIMEZONE', 'Asia/Kolkata');
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('UPLOAD_PATH', __DIR__ . '/../uploads'); 