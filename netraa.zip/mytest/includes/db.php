<?php
class Database{
    private $conn;
    
    public function __construct() {
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'my_db';
        
        try {
            $this->conn = new mysqli($host, $username, $password, $database);
            
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
            
            $this->conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            die("Database Error: " . $e->getMessage() . 
                "<br>Please ensure the database is created and properly configured.");
        }
    }
    
    public function query($sql) {
        try {
            $result = $this->conn->query($sql);
            if ($result === false) {
                throw new Exception($this->conn->error);
            }
            return $result;
        } catch (Exception $e) {
            die("Query Error: " . $e->getMessage());
        }
    }
    
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }
    
    public function escape($value) {
        return $this->conn->real_escape_string($value);
    }
    
    public function begin_transaction() {
        $this->conn->begin_transaction();
    }

    public function commit() {
        $this->conn->commit();
    }

    public function rollback() {
        $this->conn->rollback();
    }
    
    public function insert_id() {
        return $this->conn->insert_id;
    }
    
    public function __destruct() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
} 