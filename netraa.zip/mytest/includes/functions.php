<?php
if (!function_exists('checkRole')) {
    function checkRole($allowed_roles) {
        // ... existing function code ...
    }
}

if (!function_exists('logActivity')) {
    function logActivity($user_id, $action, $description = '') {
        // ... existing function code ...
    }
}

/**
 * Check if user is logged in
 * 
 * @return bool True if logged in, false otherwise
 */
function isLoggedIn() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

/**
 * Get current user's role
 * 
 * @return string|null User's role or null if not logged in
 */
function getUserRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Get current user's ID
 * 
 * @return int|null User's ID or null if not logged in
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Redirect user based on role
 * 
 * @return void
 */
function redirectBasedOnRole() {
    if (!isLoggedIn()) {
        return;
    }

    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: modules/admin/dashboard.php");
            break;
        case 'teacher':
            header("Location: modules/teacher/dashboard.php");
            break;
        case 'student':
            header("Location: modules/student/dashboard.php");
            break;
        default:
            header("Location: login.php");
    }
    exit;
}

/**
 * Login user
 * 
 * @param string $username Username
 * @param string $password Password
 * @return bool True if login successful, false otherwise
 */
function loginUser($username, $password) {
    $db = new Database();
    
    // Sanitize input
    $username = $db->escape($username);
    
    // Get user from database
    $result = $db->query("
        SELECT id, username, password, role, status 
        FROM users 
        WHERE username = '$username'
    ");
    
    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Check if account is active
            if ($user['status'] !== 'active') {
                $_SESSION['error'] = "Your account is not active. Please contact administrator.";
                return false;
            }
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            
            // Log activity
            logActivity($user['id'], 'Login', 'User logged in successfully');
            
            return true;
        }
    }
    
    return false;
}

/**
 * Logout user
 * 
 * @return void
 */
function logoutUser() {
    // Log activity before destroying session
    if (isLoggedIn()) {
        logActivity($_SESSION['user_id'], 'Logout', 'User logged out successfully');
    }
    
    // Destroy session
    session_unset();
    session_destroy();
    
    // Redirect to login page
    header("Location: /college/login.php");
    exit;
}

// Authentication checks
function checkStudentAuth() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header('Location: /login.php');
        exit();
    }
}

function checkTeacherAuth() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
        header('Location: /login.php');
        exit();
    }
}

function checkAdminAuth() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        header('Location: /login.php');
        exit();
    }
}

// Attendance functions
function markAttendance($student_id, $status, $date) {
    global $db;
    // Add attendance record
}

function getAttendanceReport($student_id, $start_date, $end_date) {
    global $db;
    // Get attendance report
}

// User management functions
function getUserDetails($user_id) {
    global $db;
    // Get user details
}

function updateUserDetails($user_id, $data) {
    global $db;
    // Update user details
}

// ... rest of your functions ... 