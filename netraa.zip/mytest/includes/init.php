<?php
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Only define constants if they're not already defined
if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost/mytest');
}

if (!defined('SITE_NAME')) {
    define('SITE_NAME', 'College Management System');
}

// Include essential files only if they haven't been included
if (!function_exists('checkRole')) {
    require_once __DIR__ . '/functions.php';
}

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set default timezone
date_default_timezone_set('Asia/Kolkata'); // Adjust to your timezone 