<?php
require_once 'includes/init.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';// Include the functions file

// Fetch college settings
$db = new Database();

// Fetch settings using the new structure
$settings = [];
$setting_keys = ['school_name', 'school_address', 'contact_email', 'contact_phone', 'logo_url'];

foreach ($setting_keys as $key) {
    $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $result = $stmt->get_result();
    $settings[$key] = $result->fetch_assoc()['setting_value'] ?? '';
}

$college_name = $settings['school_name'] ?? 'College Name';
$college_address = $settings['school_address'] ?? 'College Address';
$contact_email = $settings['contact_email'] ?? 'Contact Email';
$contact_phone = $settings['contact_phone'] ?? 'Contact Phone';
$logo_url = 'assets/images/logo.png'; // Default logo if not set
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#FFD700">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <title><?php echo $college_name; ?></title>
    <!-- Responsive Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Responsive Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <!-- Custom Responsive CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="<?php echo $logo_url; ?>" alt="Logo" width="100px" height="100px">

                <?php echo $college_name; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#statistics">Statistics</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- 
    
    Hero Section -->
    <section>
    <center>
        <h1><?php echo $college_name; ?></h1>
        <p>Streamline attendance tracking with our comprehensive digital solution</p>
        <a href="login.php" class="btn btn-primary btn-lg">Get Started</a><center/>
            </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Key Features</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card feature-card text-center">
                        <div class="card-body">
                            <i class="fas fa-user-check feature-icon"></i>
                            <h5 class="card-title">Easy Attendance Marking</h5>
                            <p class="card-text">Quick and efficient attendance marking system for teachers</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card text-center">
                        <div class="card-body">
                            <i class="fas fa-chart-bar feature-icon"></i>
                            <h5 class="card-title">Detailed Reports</h5>
                            <p class="card-text">Generate comprehensive attendance reports and analytics</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card text-center">
                        <div class="card-body">
                            <i class="fas fa-bell feature-icon"></i>
                            <h5 class="card-title">Real-time Notifications</h5>
                            <p class="card-text">Instant updates for students and teachers</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section id="statistics" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-5">System Statistics</h2>
            <div class="row text-center">
                <?php
                // Get total students
                $students = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'student'")->fetch_assoc();
                // Get total teachers
                $teachers = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'teacher'")->fetch_assoc();
                // Get total departments
                $departments = $db->query("SELECT COUNT(*) as count FROM departments")->fetch_assoc();
                ?>
                <div class="col-md-4 mb-4">
                    <h3 class="text-primary"><?php echo $students['count']; ?></h3>
                    <p class="text-muted">Students</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h3 class="text-primary"><?php echo $teachers['count']; ?></h3>
                    <p class="text-muted">Teachers</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h3 class="text-primary"><?php echo $departments['count']; ?></h3>
                    <p class="text-muted">Departments</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo $college_name; ?></h5>
                    <p>A comprehensive solution for managing college attendance</p>
                    <p><?php echo $college_address; ?></p>
                    <p>Email: <a href="mailto:<?php echo $contact_email; ?>" class="text-light"><?php echo $contact_email; ?></a></p>
                    <p>Phone: <a href="tel:<?php echo $contact_phone; ?>" class="text-light"><?php echo $contact_phone; ?></a></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="login.php" class="text-light">Login</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo $college_name; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Responsive JavaScript Enhancements
        document.addEventListener('DOMContentLoaded', function() {
            // Responsive Menu Toggle
            const menuToggle = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');
            
            if (menuToggle && navbarCollapse) {
                menuToggle.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });
            }

            // Touch-friendly dropdown menus
            const dropdowns = document.querySelectorAll('.dropdown-toggle');
            dropdowns.forEach(dropdown => {
                dropdown.addEventListener('touchstart', function(e) {
                    const parent = this.closest('.dropdown');
                    parent.classList.toggle('show');
                    this.setAttribute('aria-expanded', parent.classList.contains('show'));
                });
            });

            // Responsive image lazy loading
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                img.setAttribute('loading', 'lazy');
            });
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>
