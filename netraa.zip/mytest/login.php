<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include required files
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        $db = new Database();
        $username = $db->escape($username);
        
        $result = $db->query("SELECT * FROM users WHERE username = '$username' AND status = 'active'");
        
        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['last_activity'] = time();
                
                // // Log login activity
                // $user_id = $user['id'];
                // $db->query("INSERT INTO activity_logs (user_id, action, description) 
                //            VALUES ($user_id, 'Login', 'User logged in successfully')");
                
                // Redirect based on role
                redirectBasedOnRole();
                exit;
            }
        }
        $error = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    <style>
    /* Responsive Login Page Styles */
    * {
        box-sizing: border-box;
    }

    .login-page {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        padding: 15px;
    }

    .login-container {
        width: 100%;
        max-width: 400px;
        margin: 0 auto;
        padding: 0 15px;
    }

    .login-box {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        padding: 30px;
        width: 100%;
        max-width: 400px;
        margin: 0 auto;
    }

    .login-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .login-form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .form-group {
        position: relative;
        width: 100%;
    }

    .input-group {
        position: relative;
        width: 100%;
    }

    .input-group i {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #6b7280;
        z-index: 10;
    }

    .input-group input {
        width: 100%;
        padding: 12px 12px 12px 40px;
        border: 1px solid #d1d5db;
        border-radius: 5px;
        font-size: 16px;
        position: relative;
    }

    /* Responsive Adjustments */
    @media (max-width: 480px) {
        .login-box {
            padding: 20px;
            margin: 0 -15px; /* Counteract body padding */
            width: calc(100% + 30px);
        }

        .input-group input {
            font-size: 14px;
            padding: 10px 10px 10px 35px;
        }

        .login-header h1 {
            font-size: 20px;
        }
    }

    /* Prevent overflow and scrolling issues */
    @media (max-width: 400px) {
        .login-container,
        .login-box {
            width: 100%;
            max-width: 100%;
            padding: 0 10px;
        }
    }

    /* Accessibility and Focus States */
    .input-group input:focus {
        outline: none;
        border-color: #4361ee;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    /* Responsive Button */
    .btn-block {
        width: 100%;
        padding: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        font-size: 16px;
    }

    /* Prevent text selection and improve touch targets */
    .login-form {
        user-select: none;
        -webkit-user-select: none;
    }

    /* Touch-friendly sizing */
    @media (pointer: coarse) {
        .input-group input,
        .btn-block {
            min-height: 44px;
        }
    }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1><?php echo SITE_NAME; ?></h1>
                <p>Please login to continue</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <div class="input-group">
                        <i class="fas fa-user"></i>
                        <input type="text" id="username" name="username" 
                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                               placeholder="Enter your username"
                               required autofocus>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" 
                               placeholder="Enter your password"
                               required>
                    </div>
                </div>

                <button type="submit" class="btn-block">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>
        </div>
    </div>
</body>
</html>