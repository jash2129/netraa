<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set page title
$page_title = 'Add Class';

// Include required files in correct order
require_once '../../includes/init.php';
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../../includes/db.php';

// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module

// Initialize database
$db = new Database();

// Get all departments
$departments = $db->query("SELECT id, name, code FROM departments ORDER BY name ASC");

// Get current academic year from settings
$academic_year_query = $db->query("SELECT setting_value FROM settings WHERE setting_key = 'academic_year'");
$current_academic_year = $academic_year_query->fetch_assoc()['setting_value'] ?? date('Y').'-'.(date('Y')+1);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $department_id = $_POST['department_id'] ?? '';
    $section = $_POST['section'] ?? '';
    
    // Validate input
    $errors = [];
    if (empty($name)) {
        $errors[] = "Class name is required";
    }
    if (empty($department_id)) {
        $errors[] = "Department is required";
    }
    
    if (empty($errors)) {
        // Insert class
        $name = $db->escape($name);
        $section = $db->escape($section);
        $department_id = (int)$department_id;
        
        $result = $db->query("
            INSERT INTO classes (name, department_id, section) 
            VALUES ('$name', $department_id, '$section')
        ");
        
        if ($result) {
            $_SESSION['success'] = "Class added successfully!";
            header("Location: view_classes.php");
            exit;
        } else {
            $errors[] = "Failed to add class. Please try again.";
        }
    }
}

// Include header
require_once '../../templates/header.php';
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>Add New Class</h1>
            <a href="view_classes.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Classes
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" class="form">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="name">Class Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" required
                               value="<?php echo $_POST['name'] ?? ''; ?>"
                               placeholder="Enter class name">
                    </div>

                    <div class="form-group">
                        <label for="department_id">Department <span class="required">*</span></label>
                        <select name="department_id" id="department_id" required>
                            <option value="">Select Department</option>
                            <?php while ($dept = $departments->fetch_assoc()): ?>
                                <option value="<?php echo $dept['id']; ?>"
                                        <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $dept['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['name'] . ' (' . $dept['code'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="section">Section</label>
                        <input type="text" id="section" name="section"
                               value="<?php echo $_POST['section'] ?? ''; ?>"
                               placeholder="Enter section (optional)">
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Add Class
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.admin-content {
    padding: 20px;
    margin-left: 260px;
}

.content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
}

.required {
    color: #dc2626;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-size: 14px;
}

.form-actions {
    padding: 20px;
    background: #f9fafb;
    border-top: 1px solid #e5e7eb;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.alert {
    padding: 12px 20px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-danger {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #dc2626;
}

.alert ul {
    margin: 0;
    padding-left: 20px;
}

@media (max-width: 768px) {
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .admin-content {
        margin-left: 70px;
    }
}
</style>

<?php require_once '../../templates/footer.php'; ?> 