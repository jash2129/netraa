<?php
$page_title = 'Add Department';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module
$db = new Database();

// Get all teachers for HOD selection
$teachers = $db->query("SELECT id, username, email FROM users WHERE role = 'teacher' AND status = 'active'");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $db->escape($_POST['name']);
    $code = $db->escape($_POST['code']);

    // Check if department code already exists
    $check = $db->query("SELECT id FROM departments WHERE code = '$code'");
    
    if ($check->num_rows > 0) {
        $error = "Department code already exists";
    } else {
        $query = "INSERT INTO departments (name, code) 
                 VALUES ('$name', '$code')";
        
        if ($db->query($query)) {
            
            header("Location: view_department.php?success=1");
            exit;
        } else {
            $error = "Error creating department";
        }
    }
}
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>Add New Department</h1>
            <a href="view_department.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Departments
            </a>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" class="department-form">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="name">Department Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" required
                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
                               placeholder="Enter department name">
                    </div>

                    <div class="form-group">
                        <label for="code">Department Code <span class="required">*</span></label>
                        <input type="text" id="code" name="code" required
                               value="<?php echo isset($_POST['code']) ? htmlspecialchars($_POST['code']) : ''; ?>"
                               placeholder="e.g., CSE, ECE" maxlength="10">
                        <small>Unique code for the department</small>
                    </div>

                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Create Department
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Reuse styles from add_user.php */
</style> 