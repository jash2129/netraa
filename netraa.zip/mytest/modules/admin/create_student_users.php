<?php
require_once '../../includes/config.php';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';

// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module

// Initialize database
$db = new Database();

// Get all students from student_info table with correct column name
$students = $db->query("SELECT Roll_No, Name, DOB, Student_Email_Id, Branch FROM student_details");

$created = 0;
$errors = [];

while ($student = $students->fetch_assoc()) {
    // Skip if Roll_No is empty
    if (empty($student['Roll_No'])) {
        continue;
    }

    // Format DOB as password (remove any spaces and special characters)
    $dob = preg_replace('/[^0-9]/', '', $student['DOB']);
    if (strlen($dob) >= 8) {
        // Format as DDMMYYYY
        $password = substr($dob, 0, 8);
    } else {
        $errors[] = "Invalid DOB format for student: {$student['Roll_No']}";
        continue;
    }

    // Check if user already exists
    $existing_user = $db->query("SELECT id FROM users WHERE username = '{$student['Roll_No']}'");
    
    if ($existing_user->num_rows > 0) {
        $errors[] = "User already exists for Roll No: {$student['Roll_No']}";
        continue;
    }

    // Create new user
    $username = $db->escape($student['Roll_No']);
    $email = $db->escape($student['Student_Email_Id'] ?? $student['Roll_No'] . '@example.com');
    $branch = $db->escape($student['Branch']);
    $name_parts = explode(' ', trim($student['Name']));
    $first_name = $db->escape($name_parts[0]);
    $last_name = $db->escape(count($name_parts) > 1 ? end($name_parts) : '');
    
    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $result = $db->query("
        INSERT INTO users (
            username, 
            password, 
            email, 
            role, 
            branch, 
            first_name, 
            last_name, 
            status
        ) VALUES (
            '$username',
            '$hashed_password',
            '$email',
            'student',
            '$branch',
            '$first_name',
            '$last_name',
            'active'
        )
    ");

    if ($result) {
        $created++;
        // Log the activity
        $user_id = $db->insert_id();
        logActivity($user_id, 'Created Student User', "Created user account for student: $username");
    } else {
        $errors[] = "Failed to create user for Roll No: {$student['Roll_No']}";
    }
}

// Set messages
if ($created > 0) {
    $_SESSION['success'] = "Successfully created $created student user accounts.";
}

if (!empty($errors)) {
    $_SESSION['error'] = "Encountered the following errors:<br>" . implode("<br>", $errors);
}

// Redirect back to admin dashboard or student management page
header("Location: view_students.php");
exit;
?> 