<?php
$page_title = 'Admin Dashboard';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module

$db = new Database();

// Get basic statistics
$stats = [
    'total_students' => $db->query("SELECT COUNT(*) as count FROM student_details")->fetch_assoc()['count'],
    'total_departments' => $db->query("SELECT COUNT(*) as count FROM departments")->fetch_assoc()['count'],
];

// Get recent users
$recent_users = $db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div class="stat-details">
                    <h3>Departments</h3>
                    <div class="stat-value"><?php echo $stats['total_departments']; ?></div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon student-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="stat-details">
                    <h3>Students</h3>
                    <div class="stat-value"><?php echo $stats['total_students']; ?></div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h2>Quick Actions</h2>
            <div class="actions-grid">
                <a href="users.php?action=add" class="action-card">
                    <i class="fas fa-user-plus"></i>
                    <span>Add User</span>
                </a>
                <a href="add_department.php?action=add" class="action-card">
                    <i class="fas fa-building"></i>
                    <span>Add Department</span>
                </a>
                <a href="add_class.php?action=add" class="action-card">
                    <i class="fas fa-chalkboard"></i>
                    <span>Add Class</span>
                </a>
                <a href="settings.php" class="action-card">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </div>
        </div>

        <!-- Recent Users Table -->
        <div class="card table-card">
            <div class="card-header">
                <h2>Recent Users</h2>
                <a href="users.php" class="view-all">View All</a>
            </div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Joined Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($user = $recent_users->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><span class="badge <?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                            <td><span class="status <?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
    transition: transform 0.2s;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    background: #4361ee;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    color: white;
    font-size: 24px;
}

.student-icon { background: #2cb67d; }
.dept-icon { background: #7f5af0; }
.class-icon { background: #ff8906; }

.stat-details h3 {
    margin: 0;
    color: #666;
    font-size: 14px;
}

.stat-value {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-top: 5px;
}

.quick-actions {
    margin-bottom: 30px;
}

.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.action-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    text-decoration: none;
    color: #333;
    transition: all 0.2s;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.action-card i {
    font-size: 24px;
    margin-bottom: 10px;
    color: #4361ee;
}

.table-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.view-all {
    color: #4361ee;
    text-decoration: none;
    font-size: 14px;
}

.card-body {
    padding: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px 15px;
    text-align: left;
}

th {
    background: #f8f9fa;
    font-weight: 600;
}

tr:hover {
    background: #f8f9fa;
}

.badge {
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 12px;
}

.badge.admin { background: #e0e7ff; color: #4338ca; }
.badge.teacher { background: #fff7ed; color: #c2410c; }
.badge.student { background: #f0fdf4; color: #15803d; }

.status {
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 12px;
}

.status.active { background: #f0fdf4; color: #15803d; }
.status.inactive { background: #fef2f2; color: #dc2626; }
</style>

<?php require_once '../../templates/footer.php'; ?> 