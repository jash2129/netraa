<?php
// modules/admin/dashboard.php
require_once '../../includes/init.php';
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $db->escape($_POST['username']);
    $email = $db->escape($_POST['email']);
    $role = $db->escape($_POST['role']);
    $status = $db->escape($_POST['status']);
    $userId = intval($_POST['id']);

    $updateQuery = "UPDATE users SET username = '$username', email = '$email', role = '$role', status = '$status' WHERE id = $userId";
    $result = $db->query($updateQuery);

    if ($result) {
        $_SESSION['success'] = "User updated successfully.";
    } else {
        $_SESSION['error'] = "Failed to update the user.";
    }

    header("Location: users.php");
    exit;
}
?>

<form method="POST" action="">
    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
    <label>Username:</label>
    <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
    <label>Email:</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
    <label>Role:</label>
    <select name="role" required>
        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
        <option value="teacher" <?php echo $user['role'] === 'teacher' ? 'selected' : ''; ?>>Teacher</option>
        <option value="student" <?php echo $user['role'] === 'student' ? 'selected' : ''; ?>>Student</option>
    </select>
    <label>Status:</label>
    <select name="status" required>
        <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
        <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
    </select>
    <button type="submit">Save Changes</button>
</form>
