<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module

$db = new Database();

// Get filter parameters
$branch = $_GET['branch'] ?? '';
$from_date = $_GET['from_date'] ?? date('Y-m-01');
$to_date = $_GET['to_date'] ?? date('Y-m-d');

// Get attendance data (same query as reports.php)
// ... [previous query code] ...

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="attendance_report.xls"');
header('Cache-Control: max-age=0');

// Fetch attendance data (ensure this is done before the foreach loop)
$attendance_data = []; // Initialize as an empty array
// ... code to fetch data into $attendance_data ...

// Check if $attendance_data is an array before iterating
if (is_array($attendance_data) && !empty($attendance_data)): ?>
    <?php foreach ($attendance_data as $record): ?>
    <tr>
        <td><?php echo $record['HTNo']; ?></td>
        <td><?php echo $record['Name']; ?></td>
        <td><?php echo $record['Branch']; ?></td>
        <td><?php echo $record['total_classes']; ?></td>
        <td><?php echo $record['present_count']; ?></td>
        <td><?php echo $record['attendance_percentage']; ?>%</td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="6">No attendance data available.</td>
    </tr>
<?php endif; ?>

// Output Excel content
?>
<table border="1">
    <tr>
        <th>Roll No</th>
        <th>Name</th>
        <th>Branch</th>
        <th>Total Classes</th>
        <th>Present</th>
        <th>Attendance %</th>
    </tr>
    <?php foreach ($attendance_data as $record): ?>
    <tr>
        <td><?php echo $record['HTNo']; ?></td>
        <td><?php echo $record['Name']; ?></td>
        <td><?php echo $record['Branch']; ?></td>
        <td><?php echo $record['total_classes']; ?></td>
        <td><?php echo $record['present_count']; ?></td>
        <td><?php echo $record['attendance_percentage']; ?>%</td>
    </tr>
    <?php endforeach; ?>
</table> 