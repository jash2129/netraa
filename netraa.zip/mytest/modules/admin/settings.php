<?php
$page_title = 'System Settings';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module

$db = new Database();

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['settings'] as $key => $value) {
        $key = $db->escape($key);
        $value = $db->escape($value);
        $db->query("UPDATE settings SET setting_value = '$value' WHERE setting_key = '$key'");
    }
    $success = "Settings updated successfully!";
}

// Get current settings
$settings_query = $db->query("SELECT * FROM settings");
$settings = [];
while ($row = $settings_query->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>System Settings</h1>
        </div>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <div class="settings-grid">
            <!-- General Settings -->
            <div class="settings-card">
                <form method="POST" class="settings-form">
                    <div class="card-header">
                        <h2><i class="fas fa-cog"></i> General Settings</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>School Name</label>
                            <input type="text" name="settings[school_name]" 
                                   value="<?php echo htmlspecialchars($settings['school_name'] ?? ''); ?>"
                                   placeholder="Enter school name">
                        </div>

                        <div class="form-group">
                            <label>School Address</label>
                            <textarea name="settings[school_address]" rows="2" 
                                    placeholder="Enter school address"><?php echo htmlspecialchars($settings['school_address'] ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Contact Email</label>
                            <input type="email" name="settings[contact_email]" 
                                   value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>"
                                   placeholder="Enter contact email">
                        </div>

                        <div class="form-group">
                            <label>Contact Phone</label>
                            <input type="text" name="settings[contact_phone]" 
                                   value="<?php echo htmlspecialchars($settings['contact_phone'] ?? ''); ?>"
                                   placeholder="Enter contact phone">
                        </div>
                    </div>

                    <!-- Academic Settings -->
                    <div class="card-header">
                        <h2><i class="fas fa-graduation-cap"></i> Academic Settings</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Current Academic Year</label>
                            <input type="text" name="settings[academic_year]" 
                                   value="<?php echo htmlspecialchars($settings['academic_year'] ?? ''); ?>"
                                   placeholder="e.g., 2023-2024">
                        </div>

                        <div class="form-group">
                            <label>Current Semester</label>
                            <select name="settings[current_semester]">
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" 
                                            <?php echo ($settings['current_semester'] ?? '') == $i ? 'selected' : ''; ?>>
                                        Semester <?php echo $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Attendance Threshold (%)</label>
                            <input type="number" name="settings[attendance_threshold]" 
                                   value="<?php echo htmlspecialchars($settings['attendance_threshold'] ?? '75'); ?>"
                                   min="0" max="100">
                        </div>
                    </div>

                    <!-- System Settings -->
                    <div class="card-header">
                        <h2><i class="fas fa-shield-alt"></i> System Settings</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Maintenance Mode</label>
                            <select name="settings[maintenance_mode]">
                                <option value="0" <?php echo ($settings['maintenance_mode'] ?? '0') == '0' ? 'selected' : ''; ?>>Off</option>
                                <option value="1" <?php echo ($settings['maintenance_mode'] ?? '0') == '1' ? 'selected' : ''; ?>>On</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Session Timeout (minutes)</label>
                            <input type="number" name="settings[session_timeout]" 
                                   value="<?php echo htmlspecialchars($settings['session_timeout'] ?? '30'); ?>"
                                   min="1">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-undo"></i> Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.settings-grid {
    display: grid;
    gap: 20px;
    margin: 20px 0;
}

.settings-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
    background: #f8f9fa;
}

.card-header h2 {
    margin: 0;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #374151;
}

.card-body {
    padding: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #374151;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

.form-group textarea {
    resize: vertical;
}

.form-actions {
    padding: 20px;
    background: #f8f9fa;
    border-top: 1px solid #eee;
    display: flex;
    gap: 10px;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-primary {
    background: #4361ee;
    color: white;
}

.btn-primary:hover {
    background: #3730a3;
}

.btn-secondary {
    background: #f3f4f6;
    color: #374151;
}

.btn-secondary:hover {
    background: #e5e7eb;
}

.alert {
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-success {
    background: #f0fdf4;
    color: #15803d;
    border: 1px solid #dcfce7;
}

@media (max-width: 768px) {
    .form-actions {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<?php require_once '../../templates/footer.php'; ?> 