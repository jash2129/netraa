<?php
$page_title = 'User Management';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/admin/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['admin']); // Only admins can access this module
$db = new Database();
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $userId = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($action === 'delete' && $userId) {
        // Delete user from database
        $result = $db->query("DELETE FROM users WHERE id = $userId");

        if ($result) {
            $_SESSION['success'] = "User deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete the user.";
        }

        // Redirect to avoid repeated actions
        header("Location: users.php");
        exit;
    }

    if ($action === 'edit' && $userId) {
        // Fetch user details
        $user = $db->query("SELECT * FROM users WHERE id = $userId")->fetch_assoc();

        if ($user) {
            // Include the edit form logic (replace this with the path to your edit form)
            require_once 'edit_user_form.php';
            exit;
        } else {
            $_SESSION['error'] = "User not found.";
            header("Location: users.php");
            exit;
        }
    }
}

// Handle search and filters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$role_filter = isset($_GET['role']) ? $_GET['role'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Build query with filters
$query = "SELECT * FROM users WHERE 1=1";
if ($search) {
    $search = $db->escape($search);
    $query .= " AND (username LIKE '%$search%' OR email LIKE '%$search%')";
}
if ($role_filter) {
    $query .= " AND role = '$role_filter'";
}
if ($status_filter) {
    $query .= " AND status = '$status_filter'";
}
$query .= " ORDER BY created_at ASC";

$users = $db->query($query);
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>User Management</h1>
            <br/>
            <a href="add_user.php?action=add" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Add New User
            </a>
        </div>

        <!-- Filters Section -->
        <div class="filters-section">
            <form action="" method="GET" class="filters-form">
                <div class="search-box">
                    <input type="text" name="search" placeholder="Search users..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>

                <div class="filter-group">
                    <select name="role">
                        <option value="">All Roles</option>
                        <option value="admin" <?php echo $role_filter == 'admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="teacher" <?php echo $role_filter == 'teacher' ? 'selected' : ''; ?>>Teacher</option>
                        <option value="student" <?php echo $role_filter == 'student' ? 'selected' : ''; ?>>Student</option>
                    </select>

                    <select name="status">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>

                    <button type="submit" class="btn btn-filter">Apply Filters</button>
                    <a href="users.php" class="btn btn-clear">Clear</a>
                </div>
            </form>
        </div>

        <!-- Users Table -->
        <div class="table-card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($users && $users->num_rows > 0): ?>
                            <?php while($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="user-info">
                                            <img src="../../assets/images/<?php echo $user['role']; ?>-avatar.png" 
                                                 alt="Avatar" class="user-avatar">
                                            <span><?php echo htmlspecialchars($user['username']); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><span class="badge <?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                                    <td><span class="status <?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                    <td class="actions">
                                        <a href="users.php?action=edit&id=<?php echo $user['id']; ?>" 
                                           class="btn-icon" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="users.php?action=view&id=<?php echo $user['id']; ?>" 
                                           class="btn-icon" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($user['role'] != 'admin'): ?>
                                            <button onclick="deleteUser(<?php echo $user['id']; ?>)" 
                                                    class="btn-icon delete" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="no-data">
                                    <i class="fas fa-users"></i>
                                    <p>No users found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Additional styles for users page */
.content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.btn-primary {
    background: #4361ee;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background 0.3s;
}

.btn-primary:hover {
    background: #3730a3;
}

.filters-section {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.filters-form {
    display: flex;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
}

.search-box {
    display: flex;
    flex: 1;
    min-width: 300px;
}

.search-box input {
    flex: 1;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px 0 0 5px;
    outline: none;
}

.search-box button {
    padding: 10px 15px;
    background: #4361ee;
    color: white;
    border: none;
    border-radius: 0 5px 5px 0;
    cursor: pointer;
}

.filter-group {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.filter-group select {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline: none;
}

.btn-filter {
    padding: 10px 20px;
    background: #4361ee;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.btn-clear {
    padding: 10px 20px;
    background: #f3f4f6;
    color: #374151;
    border: none;
    border-radius: 5px;
    text-decoration: none;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.user-avatar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
}

.actions {
    display: flex;
    gap: 10px;
}

.btn-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    color: #374151;
    text-decoration: none;
    transition: all 0.3s;
}

.btn-icon:hover {
    background: #f3f4f6;
}

.btn-icon.delete {
    color: #dc2626;
    border: none;
    cursor: pointer;
    background: none;
}

.btn-icon.delete:hover {
    background: #fee2e2;
}

.no-data {
    text-align: center;
    padding: 40px;
    color: #6b7280;
}

.no-data i {
    font-size: 48px;
    margin-bottom: 10px;
}

@media (max-width: 768px) {
    .filters-form {
        flex-direction: column;
        align-items: stretch;
    }
    
    .search-box {
        min-width: auto;
    }
}
</style>

<script>
function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        // Add your delete logic here
        window.location.href = `users.php?action=delete&id=${userId}`;
    }
}
</script>

<?php require_once '../../templates/footer.php'; 

?> 
