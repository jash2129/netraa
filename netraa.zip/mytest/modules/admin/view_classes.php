<?php
$page_title = 'View Classes';

require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

checkRole(['admin']);
$db = new Database();

// Handle class deletion if requested
if (isset($_POST['delete_class'])) {
    $class_id = (int)$_POST['delete_class'];
    $result = $db->query("DELETE FROM classes WHERE id = $class_id");
    if ($result) {
        $_SESSION['success'] = "Class deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete class. It may have associated records.";
    }
    header("Location: view_classes.php");
    exit;
}

// Fetch all classes with department info and counts
$classes = $db->query("
    SELECT c.*, 
           d.name as department_name,
           COUNT(DISTINCT sc.student_id) as total_students,
           COUNT(DISTINCT ct.teacher_id) as total_teachers
    FROM classes c
    LEFT JOIN departments d ON c.department_id = d.id
    LEFT JOIN student_classes sc ON c.id = sc.class_id
    LEFT JOIN class_teachers ct ON c.id = ct.class_id
    GROUP BY c.id
    ORDER BY c.name ASC
");

require_once '../../templates/header.php';
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>Classes</h1>
            <a href="add_class.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Class
            </a>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Section</th>
                            <th>Students</th>
                            <th>Teachers</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($classes->num_rows > 0): ?>
                            <?php while ($class = $classes->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($class['name']); ?></td>
                                    <td><?php echo htmlspecialchars($class['department_name']); ?></td>
                                    <td><?php echo htmlspecialchars($class['section'] ?? 'N/A'); ?></td>
                                    <td><?php echo $class['total_students']; ?></td>
                                    <td><?php echo $class['total_teachers']; ?></td>
                                    <td><?php echo date('d M Y', strtotime($class['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="edit_class.php?id=<?php echo $class['id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="assign_teacher.php?class_id=<?php echo $class['id']; ?>" 
                                               class="btn btn-sm btn-success">
                                                <i class="fas fa-user-plus"></i>
                                            </a>
                                            <form method="POST" class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to delete this class?');">
                                                <input type="hidden" name="delete_class" value="<?php echo $class['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">No classes found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Same styles as view_departments.php */
.admin-content {
    padding: 20px;
    margin-left: 260px;
}

.content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th,
.table td {
    padding: 12px;
    border-bottom: 1px solid #e5e7eb;
}

.table th {
    background: #f9fafb;
    font-weight: 500;
    text-align: left;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.btn-sm {
    padding: 5px 10px;
    font-size: 12px;
}

.alert {
    padding: 12px 20px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-success {
    background: #dcfce7;
    border: 1px solid #bbf7d0;
    color: #15803d;
}

.alert-danger {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #dc2626;
}

@media (max-width: 768px) {
    .admin-content {
        margin-left: 70px;
    }
    
    .table-responsive {
        overflow-x: auto;
    }
}
</style>

<?php require_once '../../templates/footer.php'; ?> 