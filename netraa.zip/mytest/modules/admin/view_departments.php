<?php
$page_title = 'View Departments';

require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

checkRole(['admin']);
$db = new Database();

// Handle department deletion if requested
if (isset($_POST['delete_department'])) {
    $dept_id = (int)$_POST['delete_department'];
    $result = $db->query("DELETE FROM departments WHERE id = $dept_id");
    if ($result) {
        $_SESSION['success'] = "Department deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete department. It may have associated records.";
    }
    header("Location: view_departments.php");
    exit;
}

// Fetch all departments with additional info
$departments = $db->query("
    SELECT d.*, 
           COUNT(DISTINCT c.id) as total_classes,
           COUNT(DISTINCT s.id) as total_subjects,
           COUNT(DISTINCT t.id) as total_teachers
    FROM departments d
    LEFT JOIN classes c ON d.id = c.department_id
    LEFT JOIN subjects s ON d.id = s.department_id
    LEFT JOIN teachers t ON d.id = t.department_id
    GROUP BY d.id
    ORDER BY d.name ASC
");

require_once '../../templates/header.php';
?>

<div class="admin-layout">
    <?php require_once '../../templates/admin/sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="content-header">
            <h1>Departments</h1>
            <a href="add_department.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Department
            </a>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Code</th>
                            <th>Classes</th>
                            <th>Subjects</th>
                            <th>Teachers</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($departments->num_rows > 0): ?>
                            <?php while ($dept = $departments->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($dept['name']); ?></td>
                                    <td><?php echo htmlspecialchars($dept['code']); ?></td>
                                    <td><?php echo $dept['total_classes']; ?></td>
                                    <td><?php echo $dept['total_subjects']; ?></td>
                                    <td><?php echo $dept['total_teachers']; ?></td>
                                    <td><?php echo date('d M Y', strtotime($dept['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="edit_department.php?id=<?php echo $dept['id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form method="POST" class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to delete this department?');">
                                                <input type="hidden" name="delete_department" value="<?php echo $dept['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">No departments found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.admin-content {
    padding: 20px;
    margin-left: 260px;
}

.content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th,
.table td {
    padding: 12px;
    border-bottom: 1px solid #e5e7eb;
}

.table th {
    background: #f9fafb;
    font-weight: 500;
    text-align: left;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.btn-sm {
    padding: 5px 10px;
    font-size: 12px;
}

.alert {
    padding: 12px 20px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-success {
    background: #dcfce7;
    border: 1px solid #bbf7d0;
    color: #15803d;
}

.alert-danger {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #dc2626;
}

@media (max-width: 768px) {
    .admin-content {
        margin-left: 70px;
    }
    
    .table-responsive {
        overflow-x: auto;
    }
}
</style>

<?php require_once '../../templates/footer.php'; ?> 