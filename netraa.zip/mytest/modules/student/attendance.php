<?php
$page_title = 'My Attendance';
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';

// modules/student/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['student']); // Only students can access this module

$db = new Database();
$student_id = $_SESSION['user_id'];

// Get student details
$sql = "SELECT * from student_details where Roll_No = $student_id";
$result = $db->query($sql);
$student = $result->fetch_assoc();

$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');

// Get attendance data
$sql = "SELECT * from attendance WHERE Roll_No = '{$student_id}'";

// Check for date range filtering
if (!empty($_GET['start_date']) && !empty($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
    $sql .= " AND Date BETWEEN '{$start_date}' AND '{$end_date}'";
}

$attendance_records = $db->query($sql);

// Calculate statistics
$total_classes = $attendance_records->num_rows;
$present_count = 0;
$attendance_data = [];

while ($record = $attendance_records->fetch_assoc()) {
    if ($record['Status'] == 'Present') {
        $present_count++;
    }
    $attendance_data[] = $record;
}

$attendance_percentage = $total_classes > 0 ? ($present_count / $total_classes) * 100 : 0;
?>


<div class="student-layout">
    <?php require_once '../../templates/student/sidebar.php'; ?>
    
    <div class="student-content">
        <div class="content-header">
            <h1>Attendance Record</h1>
    
    
    <div class="filters">
        <form method="GET" class="filter-form">
            
            <div class="form-group">
                <label for="month">Month:</label>
                <input type="month" name="month" id="month" value="<?php echo $month; ?>">
            </div>

            <!-- New Date Range Inputs -->
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : ''; ?>">
            </div>
            <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date" value="<?php echo isset($_GET['end_date']) ? $_GET['end_date'] : ''; ?>">
            </div>
            
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>
    </div>
    
    <div class="attendance-stats">
        <div class="stat-card">
            <h3>Total Classes</h3>
            <div class="value"><?php echo $total_classes; ?></div>
        </div>
        <div class="stat-card">
            <h3>Classes Attended</h3>
            <div class="value"><?php echo $present_count; ?></div>
        </div>
        <div class="stat-card">
            <h3>Attendance Percentage</h3>
            <div class="value <?php echo $attendance_percentage < 75 ? 'low' : ''; ?>">
                <?php echo number_format($attendance_percentage, 1); ?>%
            </div>
        </div>
    </div>
    
    <div class="attendance-table">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Marked By</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendance_data as $record): ?>
                    <tr class="<?php echo strtolower($record['Status']); ?>">
                        <td><?php echo date('d M Y', strtotime($record['Date'])); ?></td>
                        <td><?php echo $record['Status']; ?></td>
                        <td><?php echo $record['marked_by']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>

<style>
.attendance-container {
    padding: 20px;
}

.filters {
    background: white;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.filter-form {
    display: flex;
    gap: 20px;
    align-items: flex-end;
}

.attendance-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.attendance-table {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #eee;
}

th {
    background-color: #f8f9fa;
    font-weight: 600;
}

tr.present {
    background-color: #e8f5e9;
}

tr.absent {
    background-color: #ffebee;
}

.value.low {
    color: #dc3545;
}
</style>

<?php require_once '../../templates/footer.php'; ?> 