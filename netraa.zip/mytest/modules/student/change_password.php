<?php
$page_title = 'Change Password';
require_once '../../includes/init.php';
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';

// modules/student/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['student']); // Only students can access this module


$db = new Database();
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Get current user's data
    $user_id = $_SESSION['user_id'];
    $user = $db->query("SELECT password FROM users WHERE id = $user_id")->fetch_assoc();

    // Validate input
    if (empty($current_password)) {
        $errors[] = "Current password is required";
    } elseif (!password_verify($current_password, $user['password'])) {
        $errors[] = "Current password is incorrect";
    }

    if (empty($new_password)) {
        $errors[] = "New password is required";
    } elseif (strlen($new_password) < 8) {
        $errors[] = "New password must be at least 8 characters long";
    }

    if ($new_password !== $confirm_password) {
        $errors[] = "New passwords do not match";
    }

    // If no errors, update password
    if (empty($errors)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $result = $db->query("UPDATE users SET password = '$hashed_password' WHERE id = $user_id");

        if ($result) {
            // Log the activity
            logActivity($user_id, 'Password Change', 'User changed their password');
            $success = "Password changed successfully!";
            
            // Send email notification
            $user_info = $db->query("SELECT email, first_name FROM users WHERE id = $user_id")->fetch_assoc();
            $to = $user_info['email'];
            $subject = "Password Change Notification";
            $message = "Dear {$user_info['first_name']},\n\n";
            $message .= "Your password was successfully changed on " . date('Y-m-d H:i:s') . ".\n";
            $message .= "If you did not make this change, please contact the administrator immediately.\n\n";
            $message .= "Best regards,\n";
            $message .= SITE_NAME;
            
            mail($to, $subject, $message);
        } else {
            $errors[] = "Failed to update password. Please try again.";
        }
    }
}

require_once '../../templates/header.php';
?>

<div class="student-layout">
    <?php require_once '../../templates/student/sidebar.php'; ?>
    
    <div class="student-content">
        <div class="content-header">
            <h1>Change Password</h1>
        </div>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form method="POST" class="password-form">
                    <div class="form-group">
                        <label for="current_password">Current Password <span class="required">*</span></label>
                        <div class="password-input">
                            <input type="password" id="current_password" name="current_password" required>
                            <button type="button" class="toggle-password" data-target="current_password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="new_password">New Password <span class="required">*</span></label>
                        <div class="password-input">
                            <input type="password" id="new_password" name="new_password" required 
                                   pattern=".{8,}" title="Password must be at least 8 characters long">
                            <button type="button" class="toggle-password" data-target="new_password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength" id="password-strength"></div>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password <span class="required">*</span></label>
                        <div class="password-input">
                            <input type="password" id="confirm_password" name="confirm_password" required>
                            <button type="button" class="toggle-password" data-target="confirm_password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-undo"></i> Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.password-form {
    max-width: 500px;
    margin: 0 auto;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
}

.required {
    color: #dc2626;
}

.password-input {
    position: relative;
    display: flex;
    align-items: center;
}

.password-input input {
    flex: 1;
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-size: 14px;
}

.toggle-password {
    position: absolute;
    right: 10px;
    background: none;
    border: none;
    color: #6b7280;
    cursor: pointer;
}

.password-strength {
    margin-top: 5px;
    font-size: 12px;
}

.form-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-start;
    margin-top: 30px;
}

.alert {
    padding: 12px 20px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-success {
    background: #dcfce7;
    border: 1px solid #bbf7d0;
    color: #15803d;
}

.alert-danger {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #dc2626;
}

.alert ul {
    margin: 0;
    padding-left: 20px;
}

@media (max-width: 768px) {
    .student-content {
        margin-left: 70px;
    }
}
</style>

<script>
// Toggle password visibility
document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', function() {
        const targetId = this.getAttribute('data-target');
        const input = document.getElementById(targetId);
        const icon = this.querySelector('i');

        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
});

// Password strength checker
document.getElementById('new_password').addEventListener('input', function() {
    const password = this.value;
    const strengthDiv = document.getElementById('password-strength');
    let strength = 0;
    let message = '';

    // Length check
    if (password.length >= 8) strength++;
    // Uppercase check
    if (password.match(/[A-Z]/)) strength++;
    // Lowercase check
    if (password.match(/[a-z]/)) strength++;
    // Number check
    if (password.match(/[0-9]/)) strength++;
    // Special character check
    if (password.match(/[^A-Za-z0-9]/)) strength++;

    switch(strength) {
        case 0:
        case 1:
            message = '<span style="color: #dc2626;">Very Weak</span>';
            break;
        case 2:
            message = '<span style="color: #ea580c;">Weak</span>';
            break;
        case 3:
            message = '<span style="color: #ca8a04;">Moderate</span>';
            break;
        case 4:
            message = '<span style="color: #65a30d;">Strong</span>';
            break;
        case 5:
            message = '<span style="color: #15803d;">Very Strong</span>';
            break;
    }

    strengthDiv.innerHTML = 'Password Strength: ' + message;
});

// Confirm password match checker
document.getElementById('confirm_password').addEventListener('input', function() {
    const newPassword = document.getElementById('new_password').value;
    if (this.value !== newPassword) {
        this.setCustomValidity('Passwords do not match');
    } else {
        this.setCustomValidity('');
    }
});
</script>

<?php require_once '../../templates/footer.php'; ?> 