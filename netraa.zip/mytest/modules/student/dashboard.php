<?php
$page_title = 'Student Dashboard';
require_once '../../includes/init.php';
// Include required files in correct order
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';

// modules/student/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['student']); // Only students can access this module

// Initialize database
$db = new Database();

// Get student's information
$student_id = $_SESSION['user_id'];
$student = null;

if ($student_id) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param('i', $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
}

// Get student's roll number from student_info
$student_info = null;

if ($student) {
    $stmt = $db->prepare("SELECT * FROM student_details WHERE Roll_No = ?");
    $stmt->bind_param('s', $student['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $student_info = $result->fetch_assoc();
}

// Get recent attendance
$recent_attendance = null;

if ($student) {
    $stmt = $db->prepare("
        SELECT *
        FROM attendance
        WHERE Roll_No = ?
        ORDER BY Date DESC 
        LIMIT 5
    ");
    $stmt->bind_param('s', $student['username']);
    $stmt->execute();
    $recent_attendance = $stmt->get_result();
}

// Calculate attendance percentage
$total_classes = 0;
$present_classes = 0;

if ($student) {
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM attendance WHERE Roll_No = ?");
    $stmt->bind_param('s', $student['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $total_classes = $result->fetch_assoc()['total'];

    $stmt = $db->prepare("SELECT COUNT(*) as present FROM attendance WHERE Roll_No = ? AND Status = 'Present'");
    $stmt->bind_param('s', $student['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $present_classes = $result->fetch_assoc()['present'];
}

$attendance_percentage = $total_classes > 0 ? round(($present_classes / $total_classes) * 100) : 0;

// Include header
require_once '../../templates/header.php';
?>

<div class="student-layout">
    <?php require_once '../../templates/student/sidebar.php'; ?>
    
    <div class="student-content">
        <div class="content-header">
            <h1>Welcome, <?php echo htmlspecialchars($student_info['Name'] ?? 'Student'); ?>!</h1>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="stat-details">
                    <h3>Roll Number</h3>
                    <div class="stat-value"><?php echo htmlspecialchars($student['username'] ?? 'N/A'); ?></div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon" style="background: #10b981;">
                    <i class="fas fa-chart-pie"></i>
                </div>
                <div class="stat-details">
                    <h3>Attendance</h3>
                    <div class="stat-value"><?php echo $attendance_percentage; ?>%</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon" style="background: #6366f1;">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-details">
                    <h3>Recent Attendance</h3>
                    <div class="stat-value">
                        <?php if ($recent_attendance): ?>
                            <ul>
                                <?php while ($row = $recent_attendance->fetch_assoc()): ?>
                                    <li><?php echo htmlspecialchars($row['Date'] . ': ' . $row['Status']); ?></li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p>No recent attendance records found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.student-layout {
    display: flex;
    min-height: 100vh;
}

.student-content {
    flex: 1;
    padding: 20px;
    margin-left: 260px; /* Match sidebar width */
    background: #f3f4f6;
    min-height: 100vh;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: #4361ee;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    color: white;
    font-size: 20px;
}

.stat-details h3 {
    margin: 0;
    font-size: 14px;
    color: #6b7280;
}

.stat-value {
    font-size: 24px;
    font-weight: 600;
    color: #111827;
}

.card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header h2 {
    margin: 0;
    font-size: 18px;
    color: #111827;
}

.card-body {
    padding: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #e5e7eb;
}

th {
    font-weight: 500;
    color: #6b7280;
    background: #f9fafb;
}

.badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.badge.present {
    background: #dcfce7;
    color: #15803d;
}

.badge.absent {
    background: #fee2e2;
    color: #dc2626;
}

.view-all {
    color: #4361ee;
    text-decoration: none;
    font-size: 14px;
}

.view-all:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .student-content {
        margin-left: 70px;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    table {
        display: block;
        overflow-x: auto;
    }
}
</style>

<?php require_once '../../templates/footer.php'; ?>