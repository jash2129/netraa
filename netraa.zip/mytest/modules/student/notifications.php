<?php
$page_title = 'Notifications';
require_once '../../includes/init.php';
require_once '../../templates/header.php';
// modules/student/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['student']); // Only students can access this module

$db = new Database();

// Get student's department
$sql = "SELECT d.name as department_name 
        FROM students s 
        JOIN classes c ON s.class_id = c.id 
        JOIN departments d ON c.department_id = d.id 
        WHERE s.user_id = {$_SESSION['user_id']}";
$result = $db->query($sql);
$student = $result->fetch_assoc();

// Get notifications
$notifications = getNotifications($db, 'student', $student['department_name']);
?>

<div class="notifications-container">
    <h1>Notifications</h1>
    
    <div class="notification-list">
        <?php if ($notifications->num_rows > 0): ?>
            <?php while ($notification = $notifications->fetch_assoc()): ?>
                <div class="notification-card">
                    <div class="notification-header">
                        <h3><?php echo $notification['title']; ?></h3>
                        <span class="date">
                            <?php echo date('d M Y', strtotime($notification['created_at'])); ?>
                        </span>
                    </div>
                    <div class="notification-content">
                        <?php echo nl2br($notification['content']); ?>
                    </div>
                    <?php if ($notification['attachment']): ?>
                        <div class="notification-attachment">
                            <a href="<?php echo SITE_URL; ?>/uploads/notifications/<?php echo $notification['attachment']; ?>" 
                               target="_blank" class="btn btn-secondary">
                                <i class="fas fa-paperclip"></i> View Attachment
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="notification-footer">
                        <small>Posted by: <?php echo $notification['created_by']; ?></small>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="no-notifications">
                <i class="fas fa-bell-slash"></i>
                <p>No notifications available</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.notifications-container {
    padding: 20px;
}

.notification-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.notification-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.notification-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.notification-header h3 {
    margin: 0;
    color: #2c3e50;
}

.date {
    color: #666;
    font-size: 0.9em;
}

.notification-content {
    margin-bottom: 15px;
    line-height: 1.6;
}

.notification-attachment {
    margin-bottom: 15px;
}

.notification-footer {
    color: #666;
    font-size: 0.9em;
    border-top: 1px solid #eee;
    padding-top: 10px;
}

.no-notifications {
    text-align: center;
    padding: 40px;
    background: white;
    border-radius: 8px;
    color: #666;
}

.no-notifications i {
    font-size: 48px;
    margin-bottom: 10px;
    color: #ddd;
}
</style>

<?php require_once '../../templates/footer.php'; ?> 