<?php
$page_title = 'Teacher Dashboard';
require_once '../../includes/init.php';
require_once '../../templates/header.php';
require_once '../../includes/functions.php';
require_once '../../includes/db.php';
// modules/teacher/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module

$db = new Database();
$teacher_id = $_SESSION['user_id'];

// Get today's attendance statistics
$today = date('Y-m-d');
$sql = "SELECT 
            COUNT(*) as total_marked,
            SUM(CASE WHEN Status = 'Present' THEN 1 ELSE 0 END) as present_count
        FROM attendance 
        WHERE marked_by = '{$_SESSION['username']}' 
        AND Date = '$today'";
$today_stats = $db->query($sql)->fetch_assoc();

?>
<div class="teacher-layout">
<?php require_once '../../templates/teacher/sidebar.php'; ?>

    <div class="teacher-content">
        <h1 style="text-align: center;color: #2c3e50;">Welcome, <?php echo $_SESSION['username']; ?></h1>
        
    </div>
</div>

<style>
/* Responsive Teacher Dashboard Layout */
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --background-light: #f4f6f7;
    --text-color: #333;
    
    /* Responsive Font Sizes */
    --font-size-small: clamp(0.75rem, 2vw, 1rem);
    --font-size-base: clamp(1rem, 3vw, 1.2rem);
    --font-size-large: clamp(1.2rem, 4vw, 1.5rem);
    
    /* Responsive Padding */
    --padding-small: clamp(0.5rem, 2vw, 1rem);
    --padding-medium: clamp(1rem, 3vw, 1.5rem);
    --padding-large: clamp(1.5rem, 4vw, 2rem);
}

body {
    font-size: var(--font-size-base);
}

/* Responsive Typography for Different Elements */
h1 {
    font-size: var(--font-size-large);
}

h2 {
    font-size: calc(var(--font-size-large) * 0.9);
}

h3, .section-title {
    font-size: calc(var(--font-size-base) * 1.1);
}

small, .caption {
    font-size: var(--font-size-small);
}

@media only screen and (max-width: 480px) {
    body {
        font-size: var(--font-size-small);
    }
}

/* Responsive Base Styles */
.teacher-layout {
    display: flex;
    flex-wrap: wrap;
    min-height: 100vh;
    background-color: var(--background-light);
}

/* Responsive Sidebar */
@media (max-width: 768px) {
    .teacher-layout {
        flex-direction: column;
    }
    
    .teacher-sidebar {
        width: 100%;
        position: static;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        padding: 10px;
    }
    
    .teacher-content {
        width: 100%;
        padding: 15px;
    }
}

@media (min-width: 769px) {
    .teacher-sidebar {
        width: 250px;
        position: fixed;
        left: 0;
        top: 0;
        height: 100vh;
        background-color: var(--primary-color);
        color: white;
        padding: 20px;
        transition: width 0.3s;
    }
    
    .teacher-content {
        margin-left: 250px;
        width: calc(100% - 250px);
        padding: 20px;
    }
}

/* Enhanced Responsive Media Queries */
@media only screen and (max-width: 480px) {
    body {
        font-size: var(--font-size-small);
    }
    .module-container {
        padding: var(--padding-small);
    }
}

@media only screen and (min-width: 481px) and (max-width: 768px) {
    body {
        font-size: var(--font-size-base);
    }
    .module-container {
        padding: var(--padding-medium);
    }
}

@media only screen and (min-width: 769px) {
    body {
        font-size: var(--font-size-base);
    }
    .module-container {
        padding: var(--padding-large);
    }
}

/* Touch Device Optimization */
@media (pointer: coarse) {
    .interactive-elements {
        min-height: 44px;  /* WCAG touch target size recommendation */
        min-width: 44px;
    }
}

/* Responsive Dashboard Grid */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

/* Responsive Card Styles */
.assignment-card, 
.activity-item, 
.notification-item {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 15px;
    transition: transform 0.3s ease;
}

.assignment-card:hover,
.activity-item:hover,
.notification-item:hover {
    transform: translateY(-5px);
}

/* Responsive Assignments Section */
.assignments-section {
    grid-column: 1 / -1;
}

.assignments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
}

/* Responsive Activity and Notification Sections */
.activity-item,
.notification-item {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 10px;
}

.activity-date,
.notification-date {
    min-width: 100px;
    color: #666;
    font-size: 0.9em;
}

/* Responsive Status Indicators */
.status {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.8em;
    margin-left: auto;
}

.status.present {
    background: #e8f5e9;
    color: #2e7d32;
}

.status.absent {
    background: #ffebee;
    color: #c62828;
}

/* Mobile Menu Toggle */
.mobile-menu-toggle {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: var(--secondary-color);
    color: white;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    z-index: 1000;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .mobile-menu-toggle {
        display: flex;
        justify-content: center;
        align-items: center;
    }
}

/* Responsive Scrolling */
.scrollable-section {
    max-height: 400px;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
}

.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-top: 20px;
}

.assignments-section {
    grid-column: 1 / -1;
}

.assignments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.assignment-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.assignment-card h4 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.assignment-card p {
    margin: 0 0 15px 0;
    color: #666;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.activity-date {
    min-width: 100px;
    color: #666;
}

.activity-details {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 15px;
}

.status {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.9em;
}

.status.present {
    background: #e8f5e9;
    color: #2e7d32;
}

.status.absent {
    background: #ffebee;
    color: #c62828;
}

.notification-item {
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.notification-item h4 {
    margin: 0 0 5px 0;
    color: #2c3e50;
}

.notification-item p {
    margin: 0 0 5px 0;
    color: #666;
}

.notification-item small {
    color: #999;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.classList.add('mobile-menu-toggle');
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    document.body.appendChild(mobileMenuToggle);

    const sidebar = document.querySelector('.teacher-sidebar');
    mobileMenuToggle.addEventListener('click', function() {
        sidebar.classList.toggle('mobile-sidebar-open');
        this.classList.toggle('active');
    });

    // Responsive Sidebar Management
    function manageSidebar() {
        if (window.innerWidth <= 768) {
            sidebar.style.display = sidebar.classList.contains('mobile-sidebar-open') ? 'block' : 'none';
        } else {
            sidebar.style.display = 'block';
        }
    }

    window.addEventListener('resize', manageSidebar);
    manageSidebar();
});
</script>

<?php require_once '../../templates/footer.php'; ?> 