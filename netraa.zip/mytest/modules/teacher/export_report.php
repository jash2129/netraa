<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module

// Remove header template since we're outputting Excel
// require_once '../../templates/header.php'  

$db = new Database();

// Get filter parameters
$branch = $_GET['branch'] ?? '';
$from_date = $_GET['from_date'] ?? date('Y-m-d');
$to_date = $_GET['to_date'] ?? date('Y-m-d');

// Format dates
$from_date = date('Y-m-d', strtotime($from_date));
$to_date = date('Y-m-d', strtotime($to_date));
if (!empty($branch)) {
    $branch = $db->escape($branch);
}

// Modified SQL query to ensure we get all students even if they have no attendance
$sql = "SELECT 
    s.Roll_No,
    s.Name,
    s.Branch,
    COUNT(a.date) as total_classes,
    SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
    CASE 
        WHEN COUNT(a.date) > 0 THEN 
        ROUND((SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) * 100.0) / COUNT(a.date), 2)
        ELSE 0 
    END as attendance_percentage
    FROM student_details s
    LEFT JOIN attendance a ON s.Roll_No = a.Roll_No 
        AND a.date BETWEEN '$from_date' AND '$to_date'
    WHERE 1=1";

if (!empty($branch)) {
    $sql .= " AND s.Branch = '$branch'";
}

$sql .= " GROUP BY s.Roll_No, s.Name, s.Branch
          ORDER BY s.Branch, s.Roll_No";

$attendance_data = $db->query($sql);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="attendance_report_' . date('Y-m-d') . '.xls"');
header('Cache-Control: no-cache');
header('Pragma: no-cache');

// Start output buffering
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; }
        .header { background-color: #f0f0f0; font-weight: bold; }
    </style>
</head>
<body>
<table>
    <thead>
        <tr class="header">
            <th colspan="6">Attendance Report (<?php echo $from_date; ?> to <?php echo $to_date; ?>)</th>
        </tr>
        <tr class="header">
            <th>Roll No</th>
            <th>Name</th>
            <th>Branch</th>
            <th>Total Classes</th>
            <th>Present</th>
            <th>Attendance %</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    if (is_array($attendance_data) && !empty($attendance_data)): 
        foreach ($attendance_data as $record): 
            // Skip records with no classes if needed
            if ($record['total_classes'] == 0) continue;
    ?>
        <tr>
            <td><?php echo htmlspecialchars($record['Roll_No']); ?></td>
            <td><?php echo htmlspecialchars($record['Name']); ?></td>
            <td><?php echo htmlspecialchars($record['Branch']); ?></td>
            <td><?php echo htmlspecialchars($record['total_classes']); ?></td>
            <td><?php echo htmlspecialchars($record['present_count']); ?></td>
            <td><?php echo htmlspecialchars($record['attendance_percentage']); ?>%</td>
        </tr>
    <?php 
        endforeach; 
    else: 
    ?>
        <tr>
            <td colspan="6">No attendance data available for the selected period.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</body>
</html>
<?php
// Output the buffer and end it
echo ob_get_clean();
exit();
?> 