<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
// modules/teacher/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module
$db = new Database();
$branch = $_GET['branch'] ?? '';

if (empty($branch)) {
    http_response_code(400);
    echo json_encode(['error' => 'Branch is required']);
    exit;
}

// Get students from the selected branch
$students_query = "
    SELECT HTNo, Name 
    FROM student_details
    WHERE Branch = ? 
    ORDER BY HTNo
";

$stmt = $db->prepare($students_query);
$stmt->bind_param('s', $branch);
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);


echo json_encode($students); 