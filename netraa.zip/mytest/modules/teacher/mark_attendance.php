<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
// modules/teacher/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module

$db = new Database();
$date = $_POST['selected_date'] ?? date('Y-m-d');
$branch = $_POST['selected_branch'] ?? '';
$attendance_data = $_POST['attendance'] ?? [];

try {
    $db->begin_transaction();

    // First, check if attendance already exists for this date and branch
    $check_query = "
        SELECT 1 
        FROM attendance 
        WHERE date = ? AND Roll_No IN (
            SELECT HTNo FROM student_details WHERE Branch = ?
        )
    ";
    $stmt = $db->prepare($check_query);
    $stmt->bind_param('ss', $date, $branch);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        throw new Exception('Attendance already marked for this date');
    }

    // Insert attendance records
    $insert_query = "
        INSERT INTO attendance (Roll_No, date, status, marked_by) 
        VALUES (?, ?, ?, ?)
    ";
    $stmt = $db->prepare($insert_query);

    foreach ($attendance_data as $student_id => $status) {
        $stmt->bind_param('sssi', $student_id, $date, $status, $_SESSION['user_id']);
        $stmt->execute();
    }

    $db->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $db->rollback();
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 