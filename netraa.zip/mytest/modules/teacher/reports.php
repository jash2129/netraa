<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../templates/header.php';
// modules/teacher/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module

$db = new Database();

// Get filter parameters
$branch = $_GET['branch'] ?? '';
$from_date = $_GET['from_date'] ?? date('Y-m-01'); // First day of current month
$to_date = $_GET['to_date'] ?? date('Y-m-d'); // Today

// Get all branches for filter
$branches = $db->query("SELECT DISTINCT Branch FROM student_details ORDER BY Branch")->fetch_all(MYSQLI_ASSOC);

// Build attendance query
$attendance_query = "
    SELECT 
        s.HTNo,
        s.Name,
        s.Branch,
        COUNT(a.id) as total_classes,
        COUNT(CASE WHEN a.status = 'present' THEN 1 END) as present_count,
        ROUND((COUNT(CASE WHEN a.status = 'present' THEN 1 END) * 100.0 / COUNT(a.id)), 2) as attendance_percentage
    FROM student_details s
    LEFT JOIN attendance a ON s.HTNo = a.Roll_No
    WHERE a.date BETWEEN ? AND ?
";

if ($branch) {
    $attendance_query .= " AND s.Branch = '$branch'";
}

$attendance_query .= "
    GROUP BY s.HTNo, s.Name, s.Branch
    ORDER BY s.Branch, s.HTNo
";

$stmt = $db->prepare($attendance_query);
$stmt->bind_param('ss', $from_date, $to_date);
$stmt->execute();
$attendance_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<div class="teacher-layout">
    <?php require_once '../../templates/teacher/sidebar.php'; ?>
    
    <div class="teacher-content">
<head>
    <meta charset="UTF-8">
    <title>Attendance Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../../templates/header.php'; ?>
    
    <div class="container mt-4">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Filter Reports</h5>
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label>Branch</label>
                        <select name="branch" class="form-select">
                            <option value="">All Branches</option>
                            <?php foreach ($branches as $b): ?>
                                <option value="<?php echo $b['Branch']; ?>" 
                                        <?php echo $branch == $b['Branch'] ? 'selected' : ''; ?>>
                                    <?php echo $b['Branch']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>From Date</label>
                        <input type="date" name="from_date" class="form-control" 
                               value="<?php echo $from_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label>To Date</label>
                        <input type="date" name="to_date" class="form-control" 
                               value="<?php echo $to_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                        <button type="submit" class="btn btn-primary d-block">Generate Report</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title">Attendance Report</h5>
                    <button class="btn btn-success" onclick="exportToExcel()">Export to Excel</button>
                </div>
                
                <table id="reportTable" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Roll No</th>
                            <th>Name</th>
                            <th>Branch</th>
                            <th>Total Classes</th>
                            <th>Present</th>
                            <th>Attendance %</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendance_data as $record): ?>
                        <tr>
                            <td><?php echo $record['HTNo']; ?></td>
                            <td><?php echo $record['Name']; ?></td>
                            <td><?php echo $record['Branch']; ?></td>
                            <td><?php echo $record['total_classes']; ?></td>
                            <td><?php echo $record['present_count']; ?></td>
                            <td><?php echo $record['attendance_percentage']; ?>%</td>
                            <td>
                                <?php
                                $percentage = $record['attendance_percentage'];
                                if ($percentage >= 75) {
                                    echo '<span class="badge bg-success">Good</span>';
                                } elseif ($percentage >= 60) {
                                    echo '<span class="badge bg-warning">Average</span>';
                                } else {
                                    echo '<span class="badge bg-danger">Poor</span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include '../../templates/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#reportTable').DataTable({
                pageLength: 25,
                dom: 'Bfrtip',
                buttons: ['excel']
            });
        });

        function exportToExcel() {
            window.location.href = 'export_report.php?' + new URLSearchParams(window.location.search);
        }
    </script>
</body>
</div>
</div>