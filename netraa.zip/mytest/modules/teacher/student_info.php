<?php
$page_title = 'Teacher Dashboard';
require_once '../../includes/init.php';
require_once '../../templates/header.php';
require_once '../../includes/functions.php';
require_once '../../includes/db.php';
// modules/teacher/dashboard.php
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module

$db = new Database();
$teacher_id = $_SESSION['user_id'];

// Get today's attendance statistics
$today = date('Y-m-d');
$sql = "SELECT 
            COUNT(*) as total_marked,
            SUM(CASE WHEN Status = 'Present' THEN 1 ELSE 0 END) as present_count
        FROM attendance 
        WHERE marked_by = '{$_SESSION['username']}' 
        AND Date = '$today'";
$today_stats = $db->query($sql)->fetch_assoc();

// Fetch student details if Roll_No is provided
$Roll_No = $_GET['id'] ?? null;
$student = null;

if ($Roll_No) {
    $stmt = $db->prepare("SELECT * FROM student_details WHERE Roll_No = ?");
    $stmt->bind_param('s', $Roll_No);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
}

// Handle form submission for updating student details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $student) {
    // Prepare the update statement
    $update_query = "UPDATE student_details SET 
        Name = ?, 
        Level = ?, 
        Regulation = ?, 
        Course = ?, 
        Branch = ?, 
        Semester = ?, 
        Batch = ?, 
        Admission_No = ?, 
        Year_Of_Join = ?, 
        Admission_Date = ?, 
        Admission_Type = ?, 
        Is_Lateral = ?, 
        DOB = ?, 
        Gender = ?, 
        Father_Name = ?, 
        Mother_Name = ?, 
        Parent_MobileNo = ?, 
        Student_MobileNo = ?, 
        CET_Name = ?, 
        CET_HTNo = ?, 
        CET_Rank = ?, 
        AdmnTypeCode = ?, 
        CETid = ?, 
        Sub_Branch = ?, 
        Fee_Reimb_Amt = ?, 
        DoorNo = ?, 
        Street = ?, 
        Village = ?, 
        Mandal = ?, 
        District = ?, 
        State = ?, 
        PinCode = ?, 
        Identification_Marks1 = ?, 
        Identification_Marks2 = ?, 
        Aadhar_No = ?, 
        Father_Aadhar_No = ?, 
        Mother_Aadhar_No = ?, 
        Caste_Category = ?, 
        Is_Scholarship = ?, 
        Student_Email_Id = ?, 
        Parent_Email_Id = ? 
        WHERE Roll_No = ?";

    $stmt = $db->prepare($update_query);
    // Bind parameters (make sure to match the order with the query)
    $stmt->bind_param('ssssssssssssssssssssssssssssssssssssssssssssss', 
        $_POST['Name'], 
        $_POST['Level'], 
        $_POST['Regulation'], 
        $_POST['Course'], 
        $_POST['Branch'], 
        $_POST['Semester'], 
        $_POST['Batch'], 
        $_POST['Admission_No'], 
        $_POST['Year_Of_Join'], 
        $_POST['Admission_Date'], 
        $_POST['Admission_Type'], 
        $_POST['Is_Lateral'], 
        $_POST['DOB'], 
        $_POST['Gender'], 
        $_POST['Father_Name'], 
        $_POST['Mother_Name'], 
        $_POST['Parent_MobileNo'], 
        $_POST['Student_MobileNo'], 
        $_POST['CET_Name'], 
        $_POST['CET_HTNo'], 
        $_POST['CET_Rank'], 
        $_POST['AdmnTypeCode'], 
        $_POST['CETid'], 
        $_POST['Sub_Branch'], 
        $_POST['Fee_Reimb_Amt'], 
        $_POST['DoorNo'], 
        $_POST['Street'], 
        $_POST['Village'], 
        $_POST['Mandal'], 
        $_POST['District'], 
        $_POST['State'], 
        $_POST['PinCode'], 
        $_POST['Identification_Marks1'], 
        $_POST['Identification_Marks2'], 
        $_POST['Aadhar_No'], 
        $_POST['Father_Aadhar_No'], 
        $_POST['Mother_Aadhar_No'], 
        $_POST['Caste_Category'], 
        $_POST['Is_Scholarship'], 
        $_POST['Student_Email_Id'], 
        $_POST['Parent_Email_Id'], 
        $Roll_No // Roll_No remains unchanged
    );

    if ($stmt->execute()) {
        echo "Student details updated successfully.";
    } else {
        echo "Error updating student details: " . $stmt->error;
    }
}
?>
<div class="teacher-layout">
<?php require_once '../../templates/teacher/sidebar.php'; ?>

    <div class="teacher-content">
        <h2>Edit Student Details</h2>
        <?php if ($student): ?>
            <form class="student-edit-form" method="POST">
                <input type="hidden" name="Roll_No" value="<?php echo htmlspecialchars($student['Roll_No']); ?>">
                <label>Name:</label>
                <input type="text" name="Name" value="<?php echo htmlspecialchars($student['Name']); ?>" required>
                <label>Level:</label>
                <input type="text" name="Level" value="<?php echo htmlspecialchars($student['Level']); ?>">
                <label>Regulation:</label>
                <input type="text" name="Regulation" value="<?php echo htmlspecialchars($student['Regulation']); ?>">
                <label>Course:</label>
                <input type="text" name="Course" value="<?php echo htmlspecialchars($student['Course']); ?>">
                <label>Branch:</label>
                <input type="text" name="Branch" value="<?php echo htmlspecialchars($student['Branch']); ?>">
                <label>Semester:</label>
                <input type="text" name="Semester" value="<?php echo htmlspecialchars($student['Semester']); ?>">
                <label>Batch:</label>
                <input type="text" name="Batch" value="<?php echo htmlspecialchars($student['Batch']); ?>">
                <label>Admission No:</label>
                <input type="text" name="Admission_No" value="<?php echo htmlspecialchars($student['Admission_No']); ?>">
                <label>Year Of Join:</label>
                <input type="text" name="Year_Of_Join" value="<?php echo htmlspecialchars($student['Year_Of_Join']); ?>">
                <label>Admission Date:</label>
                <input type="text" name="Admission_Date" value="<?php echo htmlspecialchars($student['Admission_Date']); ?>">
                <label>Admission Type:</label>
                <input type="text" name="Admission_Type" value="<?php echo htmlspecialchars($student['Admission_Type']); ?>">
                <label>Is Lateral:</label>
                <input type="text" name="Is_Lateral" value="<?php echo htmlspecialchars($student['Is_Lateral']); ?>">
                <label>DOB:</label>
                <input type="text" name="DOB" value="<?php echo htmlspecialchars($student['DOB']); ?>">
                <label>Gender:</label>
                <input type="text" name="Gender" value="<?php echo htmlspecialchars($student['Gender']); ?>">
                <label>Father Name:</label>
                <input type="text" name="Father_Name" value="<?php echo htmlspecialchars($student['Father_Name']); ?>">
                <label>Mother Name:</label>
                <input type="text" name="Mother_Name" value="<?php echo htmlspecialchars($student['Mother_Name']); ?>">
                <label>Parent Mobile No:</label>
                <input type="text" name="Parent_MobileNo" value="<?php echo htmlspecialchars($student['Parent_MobileNo']); ?>">
                <label>Student Mobile No:</label>
                <input type="text" name="Student_MobileNo" value="<?php echo htmlspecialchars($student['Student_MobileNo']); ?>">
                <label>CET Name:</label>
                <input type="text" name="CET_Name" value="<?php echo htmlspecialchars($student['CET_Name']); ?>">
                <label>CET HTNo:</label>
                <input type="text" name="CET_HTNo" value="<?php echo htmlspecialchars($student['CET_HTNo']); ?>">
                <label>CET Rank:</label>
                <input type="text" name="CET_Rank" value="<?php echo htmlspecialchars($student['CET_Rank']); ?>">
                <label>AdmnTypeCode:</label>
                <input type="text" name="AdmnTypeCode" value="<?php echo htmlspecialchars($student['AdmnTypeCode']); ?>">
                <label>CETid:</label>
                <input type="text" name="CETid" value="<?php echo htmlspecialchars($student['CETid']); ?>">
                <label>Sub Branch:</label>
                <input type="text" name="Sub_Branch" value="<?php echo htmlspecialchars($student['Sub_Branch']); ?>">
                <label>Fee Reimb Amt:</label>
                <input type="text" name="Fee_Reimb_Amt" value="<?php echo htmlspecialchars($student['Fee_Reimb_Amt']); ?>">
                <label>Door No:</label>
                <input type="text" name="DoorNo" value="<?php echo htmlspecialchars($student['DoorNo']); ?>">
                <label>Street:</label>
                <input type="text" name="Street" value="<?php echo htmlspecialchars($student['Street']); ?>">
                <label>Village:</label>
                <input type="text" name="Village" value="<?php echo htmlspecialchars($student['Village']); ?>">
                <label>Mandal:</label>
                <input type="text" name="Mandal" value="<?php echo htmlspecialchars($student['Mandal']); ?>">
                <label>District:</label>
                <input type="text" name="District" value="<?php echo htmlspecialchars($student['District']); ?>">
                <label>State:</label>
                <input type="text" name="State" value="<?php echo htmlspecialchars($student['State']); ?>">
                <label>Pin Code:</label>
                <input type="text" name="PinCode" value="<?php echo htmlspecialchars($student['PinCode']); ?>">
                <label>Identification Marks 1:</label>
                <input type="text" name="Identification_Marks1" value="<?php echo htmlspecialchars($student['Identification_Marks1']); ?>">
                <label>Identification Marks 2:</label>
                <input type="text" name="Identification_Marks2" value="<?php echo htmlspecialchars($student['Identification_Marks2']); ?>">
                <label>Aadhar No:</label>
                <input type="text" name="Aadhar_No" value="<?php echo htmlspecialchars($student['Aadhar_No']); ?>">
                <label>Father Aadhar No:</label>
                <input type="text" name="Father_Aadhar_No" value="<?php echo htmlspecialchars($student['Father_Aadhar No']); ?>">
                <label>Mother Aadhar No:</label>
                <input type="text" name="Mother_Aadhar_No" value="<?php echo htmlspecialchars($student['Mother_Aadhar No']); ?>">
                <label>Caste Category:</label>
                <input type="text" name="Caste_Category" value="<?php echo htmlspecialchars($student['Caste_Category']); ?>">
                <label>Is Scholarship:</label>
                <input type="text" name="Is_Scholarship" value="<?php echo htmlspecialchars($student['Is_Scholarship']); ?>">
                <label>Student Email Id:</label>
                <input type="text" name="Student_Email_Id" value="<?php echo htmlspecialchars($student['Student_Email_Id']); ?>">
                <label>Parent Email Id:</label>
                <input type="text" name="Parent_Email_Id" value="<?php echo htmlspecialchars($student['Parent_Email_Id']); ?>">
                <button type="submit">Update Details</button>
            </form>
        <?php else: ?>
            <p>No student found with the provided Roll No.</p>
        <?php endif; ?>
    </div>
</div>

<style>
.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-top: 20px;
}

.assignments-section {
    grid-column: 1 / -1;
}

.assignments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.assignment-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.assignment-card h4 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.assignment-card p {
    margin: 0 0 15px 0;
    color: #666;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.activity-date {
    min-width: 100px;
    color: #666;
}

.activity-details {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 15px;
}

.status {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.9em;
}

.status.present {
    background: #e8f5e9;
    color: #2e7d32;
}

.status.absent {
    background: #ffebee;
    color: #c62828;
}

.notification-item {
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.notification-item h4 {
    margin: 0 0 5px 0;
    color: #2c3e50;
}

.notification-item p {
    margin: 0 0 5px 0;
    color: #666;
}

.notification-item small {
    color: #999;
}

.student-edit-form {
    background-color: #f9f9f9; /* Light background for the form */
    padding: 20px; /* Add some padding */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    margin-top: 20px; /* Space above the form */
}

.student-edit-form label {
    display: block; /* Make labels block elements */
    margin-bottom: 5px; /* Space below labels */
    font-weight: bold; /* Bold labels */
}

.student-edit-form input {
    width: 100%; /* Full width inputs */
    padding: 10px; /* Padding inside inputs */
    margin-bottom: 15px; /* Space below inputs */
    border: 1px solid #ccc; /* Light border */
    border-radius: 4px; /* Rounded corners for inputs */
}

.student-edit-form button {
    background-color: #4CAF50; /* Green background for the button */
    color: white; /* White text */
    padding: 10px 15px; /* Padding for the button */
    border: none; /* No border */
    border-radius: 4px; /* Rounded corners for button */
    cursor: pointer; /* Pointer cursor on hover */
}

.student-edit-form button:hover {
    background-color: #45a049; /* Darker green on hover */
}
</style>

<?php require_once '../../templates/footer.php'; ?> 