<?php
require_once '../../includes/init.php';
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module


$db = new Database();

// Get list of branches
$branches_query = "SELECT DISTINCT Branch FROM student_details ORDER BY Branch";
$branches = $db->query($branches_query)->fetch_all(MYSQLI_ASSOC);
?>

<div class="teacher-layout">
<?php require_once '../../templates/teacher/sidebar.php'; ?>

    <div class="teacher-content">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <style>
        .loading-spinner {
            display: none;
            justify-content: center;
            align-items: center;
            height: 100px;
        }
        .loading-spinner.active {
            display: flex;
        }
    </style>
</head>
<body>
    <?php include '../../templates/header.php'; ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Students</h5>

                        <!-- Branch Selection Form -->
                        <form id="branchForm" class="mb-4">
                            <div class="row">
                                <div class="col-md-4">
                                    <select class="form-select" id="branch" name="branch" required>
                                        <option value="">Select Branch</option>
                                        <?php foreach ($branches as $branch): ?>
                                            <option value="<?php echo htmlspecialchars($branch['Branch']); ?>">
                                                <?php echo htmlspecialchars($branch['Branch']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">Get Students</button>
                                </div>
                            </div>
                        </form>

                        <!-- Loading Spinner -->
                        <div id="loadingSpinner" class="loading-spinner">
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>

                        <!-- Students Attendance Form (Populated via AJAX) -->
                        <div id="studentsAttendanceForm" style="display: none;">
                            <form id="markAttendanceForm">
                                <input type="hidden" id="selected_date" name="selected_date">
                                <input type="hidden" id="selected_branch" name="selected_branch">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Roll No</th>
                                            <th>Name</th>
                                            <th>Attendance</th>
                                        </tr>
                                    </thead>
                                    <tbody id="studentsTableBody">
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-success">Submit Attendance</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../../templates/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const branchForm = document.getElementById('branchForm');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const studentsAttendanceForm = document.getElementById('studentsAttendanceForm');
        const studentsTableBody = document.getElementById('studentsTableBody');

        branchForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const branch = document.getElementById('branch').value;

            if (!branch) {
                alert('Please select a branch.');
                return;
            }

            loadingSpinner.classList.add('active');
            studentsAttendanceForm.style.display = 'none';

            fetch(`get_students_list.php?branch=${encodeURIComponent(branch)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to fetch students.');
                    }
                    return response.json();
                })
                .then(data => {
                    studentsTableBody.innerHTML = '';
                    if (data.length === 0) {
                        alert('No students found for the selected branch and date.');
                        return;
                    }

                    data.forEach(student => {
                        studentsTableBody.innerHTML += `
                            <tr>
                                <td>${student.HTNo}</td>
                                <td>${student.Name}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="view_student_info.php?id=${student.HTNo}" 
                                           class="btn-icon" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>`;
                    });
                    document.getElementById('selected_branch').value = branch;
                    studentsAttendanceForm.style.display = 'block';
                })
                .catch(error => {
                    alert('Error: ' + error.message);
                })
                .finally(() => {
                    loadingSpinner.classList.remove('active');
                });
        });

        document.getElementById('markAttendanceForm').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch('mark_attendance.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to mark attendance.');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert('Attendance marked successfully!');
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Error: ' + error.message);
                });
        });
    </script> 
    </body>
    </div>

</div>


<style>
.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-top: 20px;
}

.assignments-section {
    grid-column: 1 / -1;
}

.assignments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.assignment-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.assignment-card h4 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.assignment-card p {
    margin: 0 0 15px 0;
    color: #666;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.activity-date {
    min-width: 100px;
    color: #666;
}

.activity-details {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 15px;
}

.status {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.9em;
}

.status.present {
    background: #e8f5e9;
    color: #2e7d32;
}

.status.absent {
    background: #ffebee;
    color: #c62828;
}

.notification-item {
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.notification-item h4 {
    margin: 0 0 5px 0;
    color: #2c3e50;
}

.notification-item p {
    margin: 0 0 5px 0;
    color: #666;
}

.notification-item small {
    color: #999;
}
</style>

<?php require_once '../../templates/footer.php'; ?> 
