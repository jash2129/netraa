<?php
$page_title = 'View Student Details';
require_once '../../includes/init.php';
require_once '../../templates/header.php';
require_once '../../includes/functions.php';
require_once '../../includes/db.php';
require_once '../../includes/auth_middleware.php';
requireAuth(['teacher']); // Only teachers can access this module


$db = new Database();

// Fetch student details if Roll_No is provided
$Roll_No = $_GET['id'] ?? null;
$student = null;

if ($Roll_No) {
    $stmt = $db->prepare("SELECT * FROM student_details WHERE Roll_No = ?");
    $stmt->bind_param('s', $Roll_No);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
}
?>

<div class="teacher-layout">
    <?php require_once '../../templates/teacher/sidebar.php'; ?>

    <div class="teacher-content">
        <h2>View Student Details</h2>
        <form method="GET" action="">
            <label for="roll_no">Enter Roll No:</label>
            <input type="text" name="id" id="id" value="<?php echo htmlspecialchars($Roll_No); ?>" required>
            <button type="submit">View Details</button>
        </form>

        <?php if ($student): ?>
            <h3>Student Information</h3>
            <p><strong>Roll No:</strong> <?php echo htmlspecialchars($student['Roll_No']); ?></p>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($student['Name']); ?></p>
            <p><strong>Level:</strong> <?php echo htmlspecialchars($student['Level']); ?></p>
            <p><strong>Regulation:</strong> <?php echo htmlspecialchars($student['Regulation']); ?></p>
            <p><strong>Course:</strong> <?php echo htmlspecialchars($student['Course']); ?></p>
            <p><strong>Branch:</strong> <?php echo htmlspecialchars($student['Branch']); ?></p>
            <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['Semester']); ?></p>
            <p><strong>Batch:</strong> <?php echo htmlspecialchars($student['Batch']); ?></p>
            <p><strong>Admission No:</strong> <?php echo htmlspecialchars($student['Admission_No']); ?></p>
            <p><strong>Year Of Join:</strong> <?php echo htmlspecialchars($student['Year_Of_Join']); ?></p>
            <p><strong>Admission Date:</strong> <?php echo htmlspecialchars($student['Admission_Date']); ?></p>
            <p><strong>Admission Type:</strong> <?php echo htmlspecialchars($student['Admission_Type']); ?></p>
            <p><strong>DOB:</strong> <?php echo htmlspecialchars($student['DOB']); ?></p>
            <p><strong>Gender:</strong> <?php echo htmlspecialchars($student['Gender']); ?></p>
            <p><strong>Father Name:</strong> <?php echo htmlspecialchars($student['Father_Name']); ?></p>
            <p><strong>Mother Name:</strong> <?php echo htmlspecialchars($student['Mother_Name']); ?></p>
            <p><strong>Parent Mobile No:</strong> <?php echo htmlspecialchars($student['Parent_MobileNo']); ?></p>
            <p><strong>Student Mobile No:</strong> <?php echo htmlspecialchars($student['Student_MobileNo']); ?></p>
            <p><strong>Student Email Id:</strong> <?php echo htmlspecialchars($student['Student_Email_Id']); ?></p>
            <p><strong>Parent Email Id:</strong> <?php echo htmlspecialchars($student['Parent_Email_Id']); ?></p>
            <!-- Add more fields as necessary -->

            <!-- Edit Button -->
            <a href="student_info.php?id=<?php echo urlencode($student['Roll_No']); ?>" class="edit-button">Edit Student Details</a>
        <?php else: ?>
            <p>No student found with the provided Roll No.</p>
        <?php endif; ?>
    </div>
</div>

<style>
.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-top: 20px;
}

.assignments-section {
    grid-column: 1 / -1;
}

.assignments-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.assignment-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.assignment-card h4 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.assignment-card p {
    margin: 0 0 15px 0;
    color: #666;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.activity-date {
    min-width: 100px;
    color: #666;
}

.activity-details {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 15px;
}

.status {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.9em;
}

.status.present {
    background: #e8f5e9;
    color: #2e7d32;
}

.status.absent {
    background: #ffebee;
    color: #c62828;
}

.notification-item {
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.notification-item h4 {
    margin: 0 0 5px 0;
    color: #2c3e50;
}

.notification-item p {
    margin: 0 0 5px 0;
    color: #666;
}

.notification-item small {
    color: #999;
}

.edit-button {
    display: inline-block;
    background-color: #007BFF; /* Bootstrap primary color */
    color: white;
    padding: 10px 15px;
    border-radius: 4px;
    text-decoration: none; /* Remove underline */
    margin-top: 10px; /* Space above the button */
}

.edit-button:hover {
    background-color: #0056b3; /* Darker blue on hover */
}
</style>

<?php require_once '../../templates/footer.php'; ?> 