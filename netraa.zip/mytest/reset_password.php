<?php
$page_title = 'Reset Password';
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = new Database();
$errors = [];
$success = '';
$token = $_GET['token'] ?? '';

// Validate token
if (empty($token)) {
    header("Location: login.php");
    exit;
}

$reset_info = $db->query("
    SELECT pr.*, u.email, u.first_name 
    FROM password_resets pr
    JOIN users u ON pr.user_id = u.id
    WHERE pr.token = '$token' 
    AND pr.used = 0 
    AND pr.expiry > NOW()
")->fetch_assoc();

if (!$reset_info) {
    $errors[] = "Invalid or expired reset link.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($errors)) {
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate passwords
    if (empty($new_password)) {
        $errors[] = "New password is required";
    } elseif (strlen($new_password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }

    if ($new_password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    if (empty($errors)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $user_id = $reset_info['user_id'];

        // Update password
        $result = $db->query("UPDATE users SET password = '$hashed_password' WHERE id = $user_id");

        if ($result) {
            // Mark token as used
            $db->query("UPDATE password_resets SET used = 1 WHERE token = '$token'");

            // Log activity
            logActivity($user_id, 'Password Reset', 'User reset their password');

            // Send confirmation email
            $to = $reset_info['email'];
            $subject = "Password Reset Successful";
            $message = "Dear {$reset_info['first_name']},\n\n";
            $message .= "Your password has been successfully reset.\n";
            $message .= "If you did not make this change, please contact support immediately.\n\n";
            $message .= "Best regards,\n";
            $message .= SITE_NAME;

            mail($to, $subject, $message);

            $success = "Password reset successful! You can now login with your new password.";
        } else {
            $errors[] = "Failed to reset password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-key"></i> Reset Password</h1>
                <p>Enter your new password</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                    <div class="mt-3">
                        <a href="login.php" class="btn btn-primary btn-block">
                            <i class="fas fa-sign-in-alt"></i> Go to Login
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (empty($errors) || !empty($_POST)): ?>
                    <form method="POST" class="auth-form">
                        <div class="form-group">
                            <label for="new_password">New Password <span class="required">*</span></label>
                            <div class="password-input">
                                <input type="password" id="new_password" name="new_password" required>
                                <button type="button" class="toggle-password" data-target="new_password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="password-strength" id="password-strength"></div>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                            <div class="password-input">
                                <input type="password" id="confirm_password" name="confirm_password" required>
                                <button type="button" class="toggle-password" data-target="confirm_password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Reset Password
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
    // Password toggle functionality
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);
            const icon = this.querySelector('i');

            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    // Password strength checker
    document.getElementById('new_password')?.addEventListener('input', function() {
        const password = this.value;
        const strengthDiv = document.getElementById('password-strength');
        let strength = 0;
        let message = '';

        if (password.length >= 8) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^A-Za-z0-9]/)) strength++;

        switch(strength) {
            case 0:
            case 1:
                message = '<span style="color: #dc2626;">Very Weak</span>';
                break;
            case 2:
                message = '<span style="color: #ea580c;">Weak</span>';
                break;
            case 3:
                message = '<span style="color: #ca8a04;">Moderate</span>';
                break;
            case 4:
                message = '<span style="color: #65a30d;">Strong</span>';
                break;
            case 5:
                message = '<span style="color: #15803d;">Very Strong</span>';
                break;
        }

        strengthDiv.innerHTML = 'Password Strength: ' + message;
    });
    </script>

    <style>
    /* Same styles as forgot_password.php plus: */
    .password-input {
        position: relative;
        display: flex;
        align-items: center;
    }

    .toggle-password {
        position: absolute;
        right: 10px;
        background: none;
        border: none;
        color: #6b7280;
        cursor: pointer;
    }

    .password-strength {
        margin-top: 5px;
        font-size: 12px;
    }

    .mt-3 {
        margin-top: 15px;
    }
    </style>
</body>
</html> 