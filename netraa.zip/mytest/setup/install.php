<?php
require_once '../includes/init.php';

try {
    // Create connection without database
    $temp_conn = new mysqli('localhost', 'root', '');
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS college
            CHARACTER SET utf8mb4
            COLLATE utf8mb4_unicode_ci";
    
    if ($temp_conn->query($sql)) {
        echo "Database created successfully<br>";
        
        // Select the database
        $temp_conn->select_db('college');
        
        // Create tables
        $tables = [
            "CREATE TABLE IF NOT EXISTS settings (...)",
            "CREATE TABLE IF NOT EXISTS departments (...)",
            "CREATE TABLE IF NOT EXISTS classes (...)",
            // Add other table creation queries
        ];
        
        foreach ($tables as $table_sql) {
            if ($temp_conn->query($table_sql)) {
                echo "Table created successfully<br>";
            }
        }
    }
    
    $temp_conn->close();
    
    echo "Setup completed successfully!";
} catch (Exception $e) {
    die("Setup Error: " . $e->getMessage());
} 