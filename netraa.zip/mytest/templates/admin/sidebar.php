<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="admin-sidebar">
    <div class="sidebar-header">
        <img src="../../assets/images/logo.png" alt="Logo" class="logo">
        <h3>Admin Panel</h3>
    </div>
    
    <nav class="sidebar-nav">
        <div class="nav-section">
            <span class="nav-section-title">MAIN</span>
            <a href="dashboard.php" class="nav-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-section-title">MANAGEMENT</span>
            <a href="users.php" class="nav-item <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>
                <span>Users</span>
            </a>
            
            <a href="reports.php" class="nav-item <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                <i class="fas fa-building"></i>
                <span>Reports</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-section-title">SYSTEM</span>
            <a href="settings.php" class="nav-item <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </div>
    </nav>
    
    <div class="sidebar-footer">
        <div class="admin-info">
            <img src="../../assets/images/admin-avatar.png" alt="Admin" class="admin-avatar">
            <div class="admin-details">
                <span class="admin-name"><?php echo $_SESSION['username']; ?></span>
                <span class="admin-role">Administrator</span>
            </div>
        </div>
        <a href="../../logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<style>
/* Add this to your existing styles or create a new CSS file */
.admin-sidebar {
    width: 280px;
    background: #1a1c23;
    color: #fff;
    display: flex;
    flex-direction: column;
    position: fixed;
    height: 100vh;
    left: 0;
    top: 0;
    z-index: 1000;
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.logo {
    width: 60px;
    height: 60px;
    margin-bottom: 10px;
    border-radius: 10px;
}

.nav-section {
    padding: 15px 0;
}

.nav-section-title {
    padding: 0 20px;
    font-size: 12px;
    font-weight: 600;
    color: rgba(255,255,255,0.4);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 10px;
}

.nav-item {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
}

.nav-item:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
    border-left-color: #4361ee;
}

.nav-item.active {
    background: rgba(255,255,255,0.1);
    color: #fff;
    border-left-color: #4361ee;
}

.nav-item i {
    width: 20px;
    margin-right: 10px;
    font-size: 18px;
}

.sidebar-footer {
    margin-top: auto;
    padding: 20px;
    background: rgba(0,0,0,0.2);
}

.admin-info {
    display: flex;
    align-items: center;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    margin-bottom: 15px;
}

.admin-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.admin-details {
    display: flex;
    flex-direction: column;
}

.admin-name {
    font-weight: 500;
}

.admin-role {
    font-size: 12px;
    color: rgba(255,255,255,0.5);
}

.logout-btn {
    display: flex;
    align-items: center;
    padding: 10px;
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.logout-btn:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
}

/* Adjust main content area to accommodate sidebar */
.admin-content {
    margin-left: 280px;
    padding: 30px;
    background: #f4f6f9;
    min-height: 100vh;
}
</style> 