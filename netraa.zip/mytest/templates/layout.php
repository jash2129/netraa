<?php
if (!defined('ROOT_PATH')) exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title ?? 'College Management System'); ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <!-- Add your CSS and JS files here -->
</head>
<body>
    <?php 
    if (isset($_SESSION['error'])): 
        echo '<div class="alert alert-danger">' . htmlspecialchars($_SESSION['error']) . '</div>';
        unset($_SESSION['error']);
    endif;
    
    if (isset($_SESSION['success'])): 
        echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
        unset($_SESSION['success']);
    endif;
    ?>
    
    <div class="content">
        <?php include $content; ?>
    </div>
    
    <script src="<?php echo BASE_URL; ?>assets/js/script.js"></script>
</body>
</html> 