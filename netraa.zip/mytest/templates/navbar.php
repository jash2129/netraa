<?php
$role = $_SESSION['role'];
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="<?php echo SITE_URL; ?>/assets/images/logo.png" alt="College Logo" class="logo">
        <h3><?php echo SITE_NAME; ?></h3>
    </div>
    
    <nav class="sidebar-nav">
        <?php if ($role == 'student'): ?>
            <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <a href="attendance.php" class="<?php echo $current_page == 'attendance.php' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-check"></i> My Attendance
            </a>
            <a href="notifications.php" class="<?php echo $current_page == 'notifications.php' ? 'active' : ''; ?>">
                <i class="fas fa-bell"></i> Notifications
            </a>
            
        <?php elseif ($role == 'teacher'): ?>
            <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <a href="mark-attendance.php" class="<?php echo $current_page == 'mark-attendance.php' ? 'active' : ''; ?>">
                <i class="fas fa-user-check"></i> Mark Attendance
            </a>
            <a href="reports.php" class="<?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="students.php" class="<?php echo $current_page == 'students.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> Students
            </a>
            <a href="notifications.php" class="<?php echo $current_page == 'notifications.php' ? 'active' : ''; ?>">
                <i class="fas fa-bell"></i> Notifications
            </a>
            
        <?php elseif ($role == 'hod'): ?>
            <!-- Similar structure for HOD menu items -->
            
        <?php elseif ($role == 'principal'): ?>
            <!-- Similar structure for Principal menu items -->
            
        <?php elseif ($role == 'admin'): ?>
            <!-- Similar structure for Admin menu items -->
        <?php endif; ?>
        
        <a href="profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i> Profile
        </a>
        <a href="<?php echo SITE_URL; ?>/logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>
</div> 