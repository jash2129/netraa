<?php
// Get current page name
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>

<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo-container">
            <img src="<?php echo SITE_URL; ?>/assets/images/logo.png" alt="Logo" class="logo">
            <h2>Teacher Panel</h2>
        </div>
        <button id="sidebar-toggle" class="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <ul>
            <li>
                <a href="dashboard.php" class="nav-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li class="nav-section">
                <span class="nav-section-title">Attendance</span>
            </li>

            <li>
                <a href="take_attendance.php" class="nav-item <?php echo $current_page == 'take_attendance.php' ? 'active' : ''; ?>">
                    <i class="fas fa-clipboard-check"></i>
                    <span>Take Attendance</span>
                </a>
            </li>

            <li>
                <a href="view_student_info.php" class="nav-item <?php echo $current_page == 'view_student_info.php' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-check"></i>
                    <span>Student Info</span>
                </a>
            </li>

            <li class="nav-section">
                <span class="nav-section-title">Management</span>
            </li>

            <li>
                <a href="students.php" class="nav-item <?php echo $current_page == 'students.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i>
                    <span>Student List</span>
                </a>
            </li>

            <li>
                <a href="reports.php" class="nav-item <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                <i class="fas fa-building"></i>
                <span>Reports</span>
            </a>
            </li>

            <li class="nav-section">
                <span class="nav-section-title">Settings</span>
            </li>
            <li class="nav-section">
                <a href="../../logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>
</div>

<style>
.sidebar {
    width: 260px;
    height: 100vh;
    background: #1f2937;
    color: #fff;
    display: flex;
    flex-direction: column;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: all 0.3s ease;
}

.sidebar-header {
    padding: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #374151;
}

.logo-container {
    display: flex;
    align-items: center;
    gap: 10px;
}

.logo {
    width: 35px;
    height: 35px;
    object-fit: contain;
}

.sidebar-header h2 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: #fff;
}

.sidebar-toggle {
    display: none;
    background: none;
    border: none;
    color: #fff;
    cursor: pointer;
    padding: 5px;
}

.sidebar-nav {
    flex: 1;
    overflow-y: auto;
    padding: 1rem 0;
}

.nav-section {
    padding: 0.75rem 1.5rem 0.5rem;
    opacity: 0.7;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.sidebar-nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar-nav a {
    display: flex;
    align-items: center;
    padding: 0.75rem 1.5rem;
    color: #9ca3af;
    text-decoration: none;
    transition: all 0.3s;
    gap: 12px;
}

.sidebar-nav a:hover {
    background: #374151;
    color: #fff;
}

.sidebar-nav a.active {
    background: #374151;
    color: #fff;
    border-left: 4px solid #4361ee;
}

.sidebar-nav i {
    width: 20px;
    text-align: center;
    font-size: 1.1rem;
}

.sidebar-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid #374151;
}

.logout-btn {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #9ca3af;
    text-decoration: none;
    padding: 0.75rem;
    border-radius: 6px;
    transition: all 0.3s;
}

.logout-btn:hover {
    background: #374151;
    color: #fff;
}
.teacher-sidebar {
    width: 280px;
    background: #1a1c23;
    color: #fff;
    display: flex;
    flex-direction: column;
    position: fixed;
    height: 100vh;
    left: 0;
    top: 0;
    z-index: 1000;
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.logo {
    width: 60px;
    height: 60px;
    margin-bottom: 10px;
    border-radius: 10px;
}

.nav-section {
    padding: 15px 0;
}

.nav-section-title {
    padding: 0 20px;
    font-size: 12px;
    font-weight: 600;
    color: rgba(255,255,255,0.4);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 10px;
}

.nav-item {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
}

.nav-item:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
    border-left-color: #4361ee;
}

.nav-item.active {
    background: rgba(255,255,255,0.1);
    color: #fff;
    border-left-color: #4361ee;
}

.nav-item i {
    width: 20px;
    margin-right: 10px;
    font-size: 18px;
}

.sidebar-footer {
    margin-top: auto;
    padding: 20px;
    background: rgba(0,0,0,0.2);
}

.teacher-info {
    display: flex;
    align-items: center;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    margin-bottom: 15px;
}

.teacher-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.teacher-details {
    display: flex;
    flex-direction: column;
}

.teacher-name {
    font-weight: 500;
}

.teacher-role {
    font-size: 12px;
    color: rgba(255,255,255,0.5);
}

.logout-btn {
    display: flex;
    align-items: center;
    padding: 10px;
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.logout-btn:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
}

/* Adjust main content area to accommodate sidebar */
.teacher-content {
    margin-left: 280px;
    padding: 30px;
    background: #f4f6f9;
    min-height: 100vh;
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
    .sidebar {
        background: #111827;
    }

    .sidebar-header {
        border-bottom-color: #1f2937;
    }

    .sidebar-nav a:hover,
    .sidebar-nav a.active {
        background: #1f2937;
    }

    .sidebar-footer {
        border-top-color: #1f2937;
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }

    .sidebar.expanded {
        width: 260px;
    }

    .sidebar-toggle {
        display: block;
    }

    .logo-container h2,
    .sidebar-nav span,
    .logout-btn span,
    .nav-section-title {
        display: none;
    }

    .sidebar.expanded .logo-container h2,
    .sidebar.expanded .sidebar-nav span,
    .sidebar.expanded .logout-btn span,
    .sidebar.expanded .nav-section-title {
        display: block;
    }

    .sidebar-nav a {
        justify-content: center;
        padding: 0.75rem;
    }

    .sidebar.expanded .sidebar-nav a {
        justify-content: flex-start;
        padding: 0.75rem 1.5rem;
    }

    .logout-btn {
        justify-content: center;
    }

    .sidebar.expanded .logout-btn {
        justify-content: flex-start;
    }
}
</style>

<script>
document.getElementById('sidebar-toggle').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('expanded');
});
</script> 